extends Node3D
## Меллстрой: побег от фога.
## Вся 3D-сцена (трасса, здания, препятствия, свет, камера) собирается кодом.
## Персонажи и костюмы — ваши PNG / покадровые листы с вырезанным зелёным фоном,
## показанные как 2D-спрайты внутри 3D-мира.

# ---------------------------------------------------------------- настройки
const INTRO_ON_RETRY := true      # показывать костюм №1 и после «Играть снова»
const SHADOWS := true             # выключите на очень слабых телефонах

const LANE_W := 2.4
const ROAD_HALF := 3.7
const SEG_LEN := 40.0
const SEG_COUNT := 4
const SPAWN_Z := -130.0

const START_SPEED := 18.0
const MAX_SPEED := 38.0
const ACCEL := 0.30
const INTRO_SPEED := 8.0
const LANE_SPEED := 26.0
const GRAVITY := 46.0
const JUMP_V := 16.0
const SLIDE_TIME := 0.7

const PLAYER_H := 2.1
const LOBBY_SPEED := 5.0

# бонусы на трассе
const PICKUP_CHANCE := 0.08      # шанс бонуса на каждый ряд препятствий
const SYRINGE_H := 0.75
const HAT_H := 1.0
const SYRINGE_TIME := 12.0       # шприц: песня + футаж + радуга
const HAT_TIME := 10.0           # шляпа: бессмертие
const EL_H := 1.9                # высота футажа вместо персонажа
const EL_COLS := 12
const EL_ROWS := 9
const EL_FRAMES := 105
const EL_FPS := 12.0

# хаммам
const HAMMAM_MAX := 10
const HAMMAM_BASE := 100
const HAMMAM_STEP := 200

# музыка лобби играет по кругу
const LOBBY_TRACKS := [
	"res://assets/audio/music1.ogg", "res://assets/audio/music3.ogg",
]

# карты. Чтобы добавить новую карту — допишите сюда словарь и (при желании)
# функцию _fill_<style>() для её объектов. "unlock" — уровень хаммама, открывающий карту.
const MAP_DEFS := [
	{"id": "city", "name": "Город", "style": "city", "preview": "", "unlock": 0,
		"sky_top": Color(0.24, 0.40, 0.76), "horizon": Color(0.95, 0.74, 0.60), "ground": Color(0.45, 0.40, 0.45),
		"fog_density": 0.016, "ambient": Color(0.62, 0.66, 0.82), "ambient_e": 0.78,
		"sun": Color(1.0, 0.90, 0.78), "sun_e": 1.05},
	{"id": "murino", "name": "Мурино", "style": "murino", "preview": "res://assets/maps/murino.webp", "unlock": 10,
		"sky_top": Color(0.40, 0.48, 0.62), "horizon": Color(0.74, 0.76, 0.80), "ground": Color(0.40, 0.42, 0.46),
		"fog_density": 0.020, "ambient": Color(0.64, 0.69, 0.80), "ambient_e": 0.78,
		"sun": Color(0.90, 0.92, 1.0), "sun_e": 0.95},
]

const RAINBOW_SHADER := """
shader_type canvas_item;
uniform sampler2D screen_tex : hint_screen_texture, repeat_disable, filter_linear;

vec3 rgb2hsv(vec3 c) {
	vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
	vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
	vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
	float d = q.x - min(q.w, q.y);
	float e = 0.0001;
	return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

vec3 hsv2rgb(vec3 c) {
	vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
	vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
	return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

void fragment() {
	vec3 col = texture(screen_tex, SCREEN_UV).rgb;
	vec3 hsv = rgb2hsv(col);
	float shift = TIME * 0.5 + SCREEN_UV.y * 1.6 + SCREEN_UV.x * 0.6;
	hsv.x = fract(hsv.x + shift);
	hsv.y = clamp(hsv.y * 1.25 + 0.45, 0.0, 1.0);
	hsv.z = clamp(hsv.z * 1.1 + 0.04, 0.0, 1.0);
	COLOR = vec4(hsv2rgb(hsv), 1.0);
}
"""

# персонажи: id, имя, картинка, цена в чекушках, высота в мире
const CHAR_DEFS := [
	{"id": "mellstroy", "name": "Меллстрой", "tex": "res://assets/sprites/mellstroy.png", "price": 0, "h": 2.1},
	{"id": "artur", "name": "Артур", "tex": "res://assets/sprites/artur.png", "price": 60, "h": 2.0},
	{"id": "kotost", "name": "Котость", "tex": "res://assets/sprites/kotost.png", "price": 100, "h": 1.6},
	{"id": "zaych", "name": "Заяц бурмалдаец", "tex": "res://assets/sprites/zaych.png", "price": 80, "h": 1.9},
]
const FOG_H := 2.2
const FOG_Z := 3.4
const COIN_H := 1.45
const SPRITE_TILT := 15.0

const CAM_POS := Vector3(0.0, 4.6, 6.4)
const CAM_LOOK := Vector3(0.0, 1.0, -5.0)
const CAM_HFOV := 58.0

const SPRITE_FILTER := BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC

const COSTUME_FPS := 12.0
const COSTUME_DEFS := [
	{"sheet": "res://assets/sprites/costume1_sheet.png", "audio": "res://assets/audio/costume1.ogg",
		"cols": 9, "rows": 10, "frames": 84, "width": 3.2},
	{"sheet": "res://assets/sprites/costume2_sheet.png", "audio": "res://assets/audio/costume2.ogg",
		"cols": 9, "rows": 9, "frames": 81, "width": 3.2},
	# «Ты просто босс» — показывается при новом рекорде
	{"sheet": "res://assets/sprites/boss_sheet.webp", "audio": "res://assets/audio/prostobos.ogg",
		"cols": 12, "rows": 9, "frames": 102, "width": 3.4},
]

const PALETTE := [
	Color(0.80, 0.62, 0.50), Color(0.62, 0.68, 0.78), Color(0.78, 0.74, 0.60),
	Color(0.55, 0.62, 0.55), Color(0.72, 0.55, 0.62), Color(0.60, 0.58, 0.70),
]
const TRAM_COLORS := [Color(0.80, 0.14, 0.12), Color(0.90, 0.60, 0.10), Color(0.15, 0.55, 0.35)]
const BUS_COLORS := [Color(0.12, 0.45, 0.86), Color(0.85, 0.80, 0.15), Color(0.55, 0.20, 0.65)]
const MURINO_PALETTE := [
	Color(0.86, 0.82, 0.70), Color(0.70, 0.78, 0.86), Color(0.80, 0.70, 0.66),
	Color(0.62, 0.74, 0.72), Color(0.88, 0.86, 0.82), Color(0.72, 0.70, 0.82),
]
const MURINO_VEH_COLORS := [Color(0.85, 0.30, 0.12), Color(0.14, 0.38, 0.62), Color(0.18, 0.50, 0.30)]
const CAR_COLORS := [Color(0.75, 0.10, 0.10), Color(0.15, 0.20, 0.45), Color(0.85, 0.85, 0.88), Color(0.15, 0.15, 0.17), Color(0.55, 0.58, 0.62)]

static var _is_retry := false
static var _lobby_track := 0

enum State { LOBBY, INTRO, RUN, DYING, OVER }

# ---------------------------------------------------------------- состояние
var _state: State = State.INTRO
var _t := 0.0
var _run_t := 0.0
var _speed := 0.0
var _dist := 0.0
var _coins_got := 0
var _best := 0
var _lane := 1
var _px := 0.0
var _py := 0.0
var _vy := 0.0
var _slide_t := 0.0
var _shake := 0.0
var _since := 0.0
var _gap := 60.0
var _touch_start := Vector2.ZERO
var _touch_active := false
var _wallet := 0
var _owned: Array = ["mellstroy"]
var _selected := "mellstroy"
var _ph := PLAYER_H
var _hammam_lvl := 0
var _maps_owned: Array = ["city"]
var _map_id := "city"
var _map_style := "city"
var _el_t := 0.0
var _imm_t := 0.0
var _new_record := false

# ---------------------------------------------------------------- ноды
var _cam: Camera3D
var _player: Area3D
var _pivot: Node3D
var _pspr: Sprite3D
var _pcol: CollisionShape3D
var _pshape: BoxShape3D
var _blob: MeshInstance3D
var _fog: Node3D
var _fog_spr: Sprite3D
var _segs: Array[Node3D] = []
var _obstacles: Array[Area3D] = []
var _coin_nodes: Array[Area3D] = []
var _costs: Array = []
var _cur_cost := -1
var _cost_t := 0.0
var _music: AudioStreamPlayer
var _sfx_pick: AudioStreamPlayer
var _sfx_eldz: AudioStreamPlayer
var _sfx_hammam: AudioStreamPlayer
var _lobby_music: AudioStreamPlayer
var _env: Environment
var _sky_mat: ProceduralSkyMaterial
var _sun: DirectionalLight3D
var _rainbow: CanvasLayer

# ресурсы
var _tex_player: Texture2D
var _char_tex := {}
var _tex_fog: Texture2D
var _tex_coin: Texture2D
var _tex_win: ImageTexture
var _tex_win_emit: ImageTexture
var _tex_blob: GradientTexture2D
var _tex_road: ImageTexture
var _tex_walk: ImageTexture
var _tex_syringe: Texture2D
var _tex_hat: Texture2D
var _tex_el: Texture2D
var _map_prev := {}
var _mats := {}

# UI
var _lbl_score: Label
var _lbl_coins: Label
var _title: Label
var _over: Control
var _lbl_final: Label
var _lbl_best: Label
var _lbl_over_coins: Label
var _btn_box: VBoxContainer
var _btn_again: Button
var _btn_quit: Button
var _hud: HBoxContainer
var _lobby: Control
var _lobby_btn: TextureButton
var _lbl_lobby_name: Label
var _lbl_wallet: Label
var _btn_play: Button
var _shop: Control
var _shop_rows: VBoxContainer
var _lbl_shop_wallet: Label
var _lbl_shop_msg: Label
var _lbl_record: Label
var _lbl_boss: Label
var _pu_box: VBoxContainer
var _row_el: HBoxContainer
var _row_imm: HBoxContainer
var _lbl_el: Label
var _lbl_imm: Label
var _btn_ham: Button
var _btn_maps: Button
var _hammam: Control
var _lbl_ham_title: Label
var _lbl_ham_cur: Label
var _ham_pic: TextureRect
var _ham_price_row: HBoxContainer
var _lbl_ham_price: Label
var _lbl_ham_wallet: Label
var _lbl_ham_msg: Label
var _btn_upgrade: Button
var _maps: Control
var _map_rows: VBoxContainer
var _lbl_maps_msg: Label
var _drop: Control
var _drop_pic: TextureRect
var _lbl_drop_name: Label


# ================================================================= запуск
func _ready() -> void:
	randomize()
	_load_save()
	_make_shared()
	_build_environment()
	_build_camera()
	for i in SEG_COUNT:
		_add_segment(20.0 - i * SEG_LEN)
	_build_player()
	_build_fog()
	_build_costumes()
	_build_audio()
	_build_ui()
	_build_rainbow()
	_apply_character()
	_start_lobby()


func _start_lobby() -> void:
	_state = State.LOBBY
	_speed = LOBBY_SPEED
	_pivot.visible = false
	_blob.visible = false
	_fog.visible = false
	_hud.visible = false
	_update_wallet_labels()
	_lobby.visible = true
	_play_lobby_music()


func _on_play() -> void:
	if _state != State.LOBBY:
		return
	_lobby_music.stop()
	_lobby.visible = false
	_hud.visible = true
	_fog.visible = true
	var skip_intro := _is_retry and not INTRO_ON_RETRY
	_is_retry = true
	if skip_intro:
		_start_run()
	else:
		_start_intro()


func _start_intro() -> void:
	_state = State.INTRO
	_speed = INTRO_SPEED
	_pivot.visible = false
	_blob.visible = false
	_play_costume(0)


func _start_run() -> void:
	_state = State.RUN
	_run_t = 0.0
	_pu_box.visible = true
	_pivot.visible = true
	_blob.visible = true
	_since = 0.0
	_gap = 70.0
	_music.play()
	if _title != null:
		var tw := create_tween()
		tw.tween_property(_title, "modulate:a", 0.0, 0.6)
	_spawn_row(-75.0)


func _crash() -> void:
	if _state != State.RUN:
		return
	_state = State.DYING
	_music.stop()
	_pivot.visible = false
	_blob.visible = false
	var old_best := _best
	_best = maxi(_best, _score())
	_new_record = _score() > old_best
	_end_powerups()
	_wallet += _coins_got
	_save_data()
	_shake = 1.0
	_play_costume(1)
	_show_over_title()


# ================================================================= ресурсы
func _load_tex_mips(path: String) -> Texture2D:
	## Картинка с мипмапами и «подчищенными» краями альфы — гладкий силуэт на расстоянии.
	var src: Texture2D = load(path)
	var img: Image = src.get_image()
	if img == null:
		return src
	if img.is_compressed():
		img.decompress()
	img.convert(Image.FORMAT_RGBA8)
	img.fix_alpha_edges()
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func _make_shared() -> void:
	for d in CHAR_DEFS:
		_char_tex[d["id"]] = _load_tex_mips(d["tex"])
	_tex_player = _char_tex["mellstroy"]
	_tex_fog = _load_tex_mips("res://assets/sprites/fog.png")
	_tex_coin = _load_tex_mips("res://assets/sprites/chekushka.png")
	_tex_syringe = _load_tex_mips("res://assets/sprites/syringe.png")
	_tex_hat = _load_tex_mips("res://assets/sprites/hat.png")
	_tex_el = load("res://assets/sprites/eldz_sheet.webp")
	# фасад с окнами: albedo + emission (горящие окна), рамы, переплёты, подоконники
	var a := Image.create_empty(128, 256, true, Image.FORMAT_RGBA8)
	var e := Image.create_empty(128, 256, true, Image.FORMAT_RGBA8)
	a.fill(Color(1, 1, 1, 1))
	e.fill(Color(0, 0, 0, 1))
	var frame := Color(0.74, 0.74, 0.76)
	var sill := Color(0.62, 0.62, 0.64)
	for row in 8:
		for col in 4:
			var ox := col * 32 + 6
			var oy := row * 32 + 8
			var r := Rect2i(ox, oy, 20, 16)
			a.fill_rect(Rect2i(ox - 2, oy - 2, 24, 20), frame)
			a.fill_rect(Rect2i(ox - 3, oy + 18, 26, 3), sill)
			var lit := randf() < 0.4
			if lit:
				a.fill_rect(Rect2i(r.position.x, r.position.y, r.size.x, 8), Color(0.98, 0.90, 0.62))
				a.fill_rect(Rect2i(r.position.x, r.position.y + 8, r.size.x, 8), Color(0.88, 0.72, 0.44))
				e.fill_rect(Rect2i(r.position.x, r.position.y, r.size.x, 8), Color(1.0, 0.78, 0.38))
				e.fill_rect(Rect2i(r.position.x, r.position.y + 8, r.size.x, 8), Color(0.85, 0.55, 0.24))
			else:
				a.fill_rect(Rect2i(r.position.x, r.position.y, r.size.x, 8), Color(0.20, 0.27, 0.40))
				a.fill_rect(Rect2i(r.position.x, r.position.y + 8, r.size.x, 8), Color(0.10, 0.14, 0.22))
			# переплёт
			a.fill_rect(Rect2i(ox + 9, oy, 2, 16), frame)
			a.fill_rect(Rect2i(ox, oy + 7, 20, 2), frame)
			if lit:
				e.fill_rect(Rect2i(ox + 9, oy, 2, 16), Color(0, 0, 0, 1))
				e.fill_rect(Rect2i(ox, oy + 7, 20, 2), Color(0, 0, 0, 1))
	a.generate_mipmaps()
	e.generate_mipmaps()
	_tex_win = ImageTexture.create_from_image(a)
	_tex_win_emit = ImageTexture.create_from_image(e)
	# асфальт: мелкое зерно
	var ri := Image.create_empty(128, 128, true, Image.FORMAT_RGBA8)
	for y in 128:
		for x in 128:
			var n := randf_range(-0.035, 0.035)
			if randf() < 0.02:
				n += 0.06
			ri.set_pixel(x, y, Color(0.17 + n, 0.17 + n, 0.19 + n, 1.0))
	ri.generate_mipmaps()
	_tex_road = ImageTexture.create_from_image(ri)
	# тротуарная плитка: швы + зерно
	var wi := Image.create_empty(64, 64, true, Image.FORMAT_RGBA8)
	for y in 64:
		for x in 64:
			var n2 := randf_range(-0.02, 0.02)
			var seam := (x % 32 < 2) or (y % 32 < 2)
			var v := (0.46 if seam else 0.58) + n2
			wi.set_pixel(x, y, Color(v, v - 0.01, v - 0.03, 1.0))
	wi.generate_mipmaps()
	_tex_walk = ImageTexture.create_from_image(wi)
	# мягкая тень под игроком
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0, 0, 0, 0.60), Color(0, 0, 0, 0.30), Color(0, 0, 0, 0.0)])
	g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	_tex_blob = GradientTexture2D.new()
	_tex_blob.gradient = g
	_tex_blob.fill = GradientTexture2D.FILL_RADIAL
	_tex_blob.fill_from = Vector2(0.5, 0.5)
	_tex_blob.fill_to = Vector2(1.0, 0.5)
	_tex_blob.width = 128
	_tex_blob.height = 128


func _mat(c: Color, emit: float = 0.0, rough: float = 0.85, metal: float = 0.0) -> StandardMaterial3D:
	var key := "%s|%s|%s|%s" % [c.to_html(), emit, rough, metal]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	m.metallic_specular = 0.5
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emit
	_mats[key] = m
	return m


func _tex_mat(tex: Texture2D, uv_scale: Vector3, rough: float = 0.9) -> StandardMaterial3D:
	var key := "tex|%s|%s" % [tex.get_rid().get_id(), uv_scale]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.uv1_scale = uv_scale
	m.roughness = rough
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	m.texture_repeat = true
	_mats[key] = m
	return m


func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


func _cyl(parent: Node3D, r_top: float, r_bot: float, h: float, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r_top
	cm.bottom_radius = r_bot
	cm.height = h
	cm.radial_segments = 16
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


## 2D-картинка (или покадровый лист) как Sprite3D. Низ спрайта стоит в точке пивота.
func _make_sprite(tex: Texture2D, height: float, hframes: int = 1, vframes: int = 1) -> Node3D:
	var pivot := Node3D.new()
	var s := Sprite3D.new()
	s.texture = tex
	s.hframes = hframes
	s.vframes = vframes
	var fh := float(tex.get_height()) / float(vframes)
	s.pixel_size = height / fh
	s.alpha_cut = SpriteBase3D.ALPHA_CUT_OPAQUE_PREPASS   # сглаженные края силуэта
	s.alpha_scissor_threshold = 0.5
	s.shaded = false
	s.texture_filter = SPRITE_FILTER
	s.position.y = height * 0.5
	pivot.rotation_degrees.x = -SPRITE_TILT
	pivot.add_child(s)
	return pivot


# ================================================================= мир
func _build_environment() -> void:
	var horizon := Color(0.95, 0.74, 0.60)
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.24, 0.40, 0.76)
	sm.sky_horizon_color = horizon
	sm.ground_horizon_color = horizon
	sm.ground_bottom_color = Color(0.45, 0.40, 0.45)
	sm.sky_curve = 0.18
	sm.ground_curve = 0.04
	sm.sun_angle_max = 30.0
	sm.sun_curve = 0.15
	var sky := Sky.new()
	sky.sky_material = sm
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.62, 0.66, 0.82)
	env.ambient_light_energy = 0.78
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	# свечение горящих окон и фонарей
	env.glow_enabled = true
	env.glow_intensity = 0.55
	env.glow_strength = 1.0
	env.glow_bloom = 0.0
	env.glow_hdr_threshold = 0.9
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	# цветокоррекция
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.06
	env.adjustment_saturation = 1.14
	env.fog_enabled = true
	env.fog_light_color = horizon
	env.fog_density = 0.016
	env.fog_sky_affect = 0.0
	env.fog_sun_scatter = 0.15
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	_env = env
	_sky_mat = sm

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
	sun.light_color = Color(1.0, 0.90, 0.78)
	sun.light_energy = 1.05
	sun.shadow_enabled = SHADOWS
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_split_1 = 0.25
	sun.directional_shadow_max_distance = 60.0
	sun.directional_shadow_blend_splits = true
	sun.shadow_blur = 1.4
	sun.shadow_normal_bias = 1.0
	add_child(sun)
	_sun = sun
	_apply_map_env()


func _build_camera() -> void:
	_cam = Camera3D.new()
	_cam.keep_aspect = Camera3D.KEEP_WIDTH   # три полосы влезают на любом портретном экране
	_cam.fov = CAM_HFOV
	_cam.near = 0.1
	_cam.far = 220.0
	add_child(_cam)
	_cam.current = true
	_cam.position = CAM_POS
	_cam.look_at(CAM_LOOK)


func _add_segment(z0: float) -> void:
	var s := Node3D.new()
	s.position.z = z0
	add_child(s)
	_segs.append(s)
	if _map_style == "murino":
		_fill_murino(s)
	else:
		_fill_city(s)


func _fill_city(s: Node3D) -> void:
	# дорога
	_box(s, Vector3(ROAD_HALF * 2.0, 0.4, SEG_LEN + 0.05), Vector3(0, -0.2, -SEG_LEN * 0.5), _tex_mat(_tex_road, Vector3(ROAD_HALF * 2.0 / 2.0, SEG_LEN / 2.0, 1.0), 0.8))
	# разметка
	var white := _mat(Color(0.85, 0.85, 0.80))
	for sx: float in [-0.5, 0.5]:
		for k in 5:
			_box(s, Vector3(0.14, 0.02, 4.0), Vector3(sx * LANE_W, 0.01, -4.0 - k * 8.0), white)
	for side: int in [-1, 1]:
		# тротуар
		_box(s, Vector3(2.2, 0.3, SEG_LEN + 0.05), Vector3(side * (ROAD_HALF + 1.1), 0.15, -SEG_LEN * 0.5), _tex_mat(_tex_walk, Vector3(1.1, SEG_LEN / 2.0, 1.0), 0.9))
		# здания
		var zc := 0.0
		while zc > -SEG_LEN + 6.0:
			var d := minf(randf_range(10.0, 16.0), SEG_LEN + zc)
			var w := randf_range(7.0, 13.0)
			var h := randf_range(10.0, 34.0)
			_building(s, Vector3(side * (ROAD_HALF + 2.5 + w * 0.5), h * 0.5, zc - d * 0.5), Vector3(w, h, d), side)
			zc -= d + randf_range(0.0, 1.5)
		# фонари
		for zl: float in [-8.0, -28.0]:
			_lamp(s, Vector3(side * (ROAD_HALF + 0.5), 0.0, zl), side)
		# дерево
		var tz := randf_range(-16.0, -4.0)
		var tx := side * (ROAD_HALF + 1.6)
		_cyl(s, 0.12, 0.17, 1.8, Vector3(tx, 0.9, tz), _mat(Color(0.35, 0.24, 0.15)))
		var crown := MeshInstance3D.new()
		var sph := SphereMesh.new()
		sph.radius = 1.1
		sph.height = 2.2
		sph.radial_segments = 20
		sph.rings = 10
		crown.mesh = sph
		crown.material_override = _mat(Color(0.20, 0.45 + randf() * 0.2, 0.22))
		crown.position = Vector3(tx, 2.7, tz)
		s.add_child(crown)
		var crown2 := MeshInstance3D.new()
		var sph2 := SphereMesh.new()
		sph2.radius = 0.8
		sph2.height = 1.6
		sph2.radial_segments = 16
		sph2.rings = 8
		crown2.mesh = sph2
		crown2.material_override = crown.material_override
		crown2.position = Vector3(tx + 0.4, 3.4, tz - 0.2)
		s.add_child(crown2)
		# мусорный бак
		_box(s, Vector3(1.3, 1.1, 1.9), Vector3(side * (ROAD_HALF + 1.4), 0.85, randf_range(-36.0, -24.0)), _mat(Color(0.18, 0.36, 0.28)))


func _building(parent: Node3D, center: Vector3, size: Vector3, side: int, murino: bool = false) -> void:
	var col: Color = MURINO_PALETTE.pick_random() if murino else PALETTE.pick_random()
	_box(parent, size, center, _mat(col))
	_box(parent, Vector3(size.x + 0.4, 0.4, size.z + 0.4), Vector3(center.x, center.y + size.y * 0.5 + 0.2, center.z), _mat(col.darkened(0.15)))
	_box(parent, Vector3(size.x + 0.25, 1.2, size.z + 0.25), Vector3(center.x, 0.6, center.z), _mat(col.darkened(0.3)))
	var q := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(size.z, size.y)
	q.mesh = qm
	var m := StandardMaterial3D.new()
	m.albedo_texture = _tex_win
	m.albedo_color = col.lightened(0.12)
	if murino:
		m.uv1_scale = Vector3(size.z / 8.0, size.y / 16.0, 1.0)
	else:
		m.uv1_scale = Vector3(size.z / 12.0, size.y / 24.0, 1.0)
	m.roughness = 0.9
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	m.emission_enabled = true
	m.emission = Color(1, 1, 1)
	m.emission_texture = _tex_win_emit
	m.emission_energy_multiplier = 1.1
	q.material_override = m
	q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	q.position = Vector3(center.x - side * (size.x * 0.5 + 0.03), center.y, center.z)
	q.rotation_degrees.y = -90.0 * side
	parent.add_child(q)
	if randf() < 0.5:
		_box(parent, Vector3(size.x * 0.4, 1.6, size.z * 0.3), Vector3(center.x, center.y + size.y * 0.5 + 0.8, center.z), _mat(Color(0.30, 0.30, 0.33)))


func _lamp(parent: Node3D, pos: Vector3, side: int) -> void:
	var metal := _mat(Color(0.22, 0.23, 0.27), 0.0, 0.45, 0.6)
	_cyl(parent, 0.07, 0.10, 5.2, pos + Vector3(0, 2.6, 0), metal)
	_box(parent, Vector3(1.1, 0.08, 0.08), pos + Vector3(-side * 0.55, 5.2, 0), metal)
	_box(parent, Vector3(0.5, 0.12, 0.3), pos + Vector3(-side * 1.05, 5.12, 0), _mat(Color(1.0, 0.85, 0.55), 2.5))


# ================================================================= препятствия
func _build_vehicle(root: Node3D, tram: bool) -> Dictionary:
	var vlen := 14.0 if tram else 8.0
	var h := 2.9 if tram else 2.5
	var base := 0.35 if tram else 0.5
	var body: Color = TRAM_COLORS.pick_random() if tram else BUS_COLORS.pick_random()
	var glass := _mat(Color(0.08, 0.12, 0.20), 0.0, 0.06, 0.6)
	_box(root, Vector3(2.0, 0.5, vlen - 1.0), Vector3(0, 0.3, 0), _mat(Color(0.10, 0.10, 0.12)))
	_box(root, Vector3(2.1, h, vlen), Vector3(0, base + h * 0.5, 0), _mat(body, 0.0, 0.32, 0.25))
	_box(root, Vector3(2.14, 0.22, vlen - 0.1), Vector3(0, base + h * 0.36, 0), _mat(Color(0.95, 0.92, 0.85)))
	_box(root, Vector3(2.14, 0.8, vlen - 1.6), Vector3(0, base + h * 0.72, 0), glass)
	_box(root, Vector3(1.7, 1.0, 0.06), Vector3(0, base + h * 0.70, vlen * 0.5 + 0.02), glass)
	var lamp := _mat(Color(1.0, 0.95, 0.6), 2.0)
	_box(root, Vector3(0.3, 0.2, 0.08), Vector3(-0.7, base + 0.35, vlen * 0.5 + 0.03), lamp)
	_box(root, Vector3(0.3, 0.2, 0.08), Vector3(0.7, base + 0.35, vlen * 0.5 + 0.03), lamp)
	_box(root, Vector3(1.4, 0.25, vlen * 0.4), Vector3(0, base + h + 0.12, 0), _mat(Color(0.55, 0.57, 0.60), 0.0, 0.5, 0.5))
	# колёса
	var tyre := _mat(Color(0.05, 0.05, 0.06), 0.0, 0.9)
	var wz: Array = [vlen * 0.5 - 1.6, -vlen * 0.5 + 1.6]
	if tram:
		wz.append(0.0)
	for z: float in wz:
		for sx: float in [-1.0, 1.0]:
			var wheel := _cyl(root, 0.42, 0.42, 0.3, Vector3(sx * 0.98, 0.42, z), tyre)
			wheel.rotation_degrees.z = 90.0
	return {"len": vlen, "shape": Vector3(1.9, base + h, vlen), "cy": (base + h) * 0.5}


func _build_barrier(root: Node3D) -> Dictionary:
	var post := _mat(Color(0.85, 0.85, 0.85))
	_box(root, Vector3(0.18, 0.9, 0.18), Vector3(-0.85, 0.45, 0), post)
	_box(root, Vector3(0.18, 0.9, 0.18), Vector3(0.85, 0.45, 0), post)
	_box(root, Vector3(2.0, 0.45, 0.2), Vector3(0, 0.62, 0), _mat(Color(0.85, 0.12, 0.10)))
	for sx: float in [-0.6, 0.0, 0.6]:
		_box(root, Vector3(0.32, 0.46, 0.22), Vector3(sx, 0.62, 0), post)
	return {"len": 1.6, "shape": Vector3(2.0, 0.9, 0.6), "cy": 0.45}


func _build_crate(root: Node3D) -> Dictionary:
	_box(root, Vector3(1.7, 1.0, 1.2), Vector3(0, 0.5, 0), _mat(Color(0.60, 0.42, 0.22)))
	var strap := _mat(Color(0.35, 0.24, 0.12))
	_box(root, Vector3(1.74, 0.12, 1.24), Vector3(0, 0.15, 0), strap)
	_box(root, Vector3(1.74, 0.12, 1.24), Vector3(0, 0.85, 0), strap)
	return {"len": 1.6, "shape": Vector3(1.7, 1.0, 1.2), "cy": 0.5}


func _build_overhead(root: Node3D) -> Dictionary:
	var metal := _mat(Color(0.25, 0.26, 0.30), 0.0, 0.45, 0.6)
	_box(root, Vector3(0.2, 2.5, 0.2), Vector3(-1.05, 1.25, 0), metal)
	_box(root, Vector3(0.2, 2.5, 0.2), Vector3(1.05, 1.25, 0), metal)
	_box(root, Vector3(2.3, 0.7, 0.35), Vector3(0, 1.85, 0), _mat(Color(0.95, 0.78, 0.10)))
	var dark := _mat(Color(0.10, 0.10, 0.10))
	for sx: float in [-0.7, 0.0, 0.7]:
		_box(root, Vector3(0.3, 0.72, 0.37), Vector3(sx, 1.85, 0), dark)
	return {"len": 1.2, "shape": Vector3(2.0, 0.75, 0.5), "cy": 1.85}


func _spawn_obstacle(kind: String, lane: int, z_near: float) -> void:
	var a := Area3D.new()
	a.monitoring = false
	a.set_meta("kind", "hazard")
	var info: Dictionary
	var mur := _map_style == "murino"
	match kind:
		"tram": info = _build_truck(a, true) if mur else _build_vehicle(a, true)
		"bus": info = _build_truck(a, false) if mur else _build_vehicle(a, false)
		"barrier": info = _build_jersey(a) if mur else _build_barrier(a)
		"crate": info = _build_skip(a) if mur else _build_crate(a)
		_: info = _build_gantry(a) if mur else _build_overhead(a)
	var col := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = info["shape"]
	col.shape = bs
	col.position.y = info["cy"]
	a.add_child(col)
	a.position = Vector3((lane - 1) * LANE_W, 0.0, z_near - float(info["len"]) * 0.5)
	add_child(a)
	_obstacles.append(a)


func _spawn_coin(lane: int, z: float, y: float) -> void:
	var a := Area3D.new()
	a.monitoring = false
	a.set_meta("kind", "coin")
	var piv := _make_sprite(_tex_coin, COIN_H)
	a.add_child(piv)
	a.set_meta("spr", piv.get_child(0))
	a.set_meta("ph", randf() * TAU)
	var col := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.0, COIN_H, 0.8)
	col.shape = bs
	col.position.y = COIN_H * 0.5
	a.add_child(col)
	a.position = Vector3((lane - 1) * LANE_W, y - COIN_H * 0.5, z)
	add_child(a)
	_coin_nodes.append(a)


func _spawn_coin_line(lane: int, z_start: float, count: int) -> void:
	for i in maxi(count, 0):
		_spawn_coin(lane, z_start - i * 2.0, 0.95)


## Создаёт ряд препятствий (всегда остаётся свободная полоса). Возвращает дистанцию до следующего ряда.
func _spawn_row(z_near: float) -> float:
	var lanes: Array[int] = [0, 1, 2]
	lanes.shuffle()
	var diff := clampf(_run_t / 90.0, 0.0, 1.0)
	var r := randf()
	var length := 1.6
	if r < 0.30:
		var n := 2 if randf() < 0.25 + 0.35 * diff else 1
		for i in n:
			_spawn_obstacle(["barrier", "crate"].pick_random(), lanes[i], z_near)
		_spawn_coin_line(lanes[n], z_near - 0.5, 5)
	elif r < 0.45:
		length = 1.2
		var n2 := 2 if randf() < 0.2 + 0.3 * diff else 1
		for i in n2:
			_spawn_obstacle("overhead", lanes[i], z_near)
		_spawn_coin_line(lanes[n2], z_near - 0.5, 4)
	elif r < 0.78:
		var tram := randf() < 0.5
		length = 14.0 if tram else 8.0
		_spawn_obstacle("tram" if tram else "bus", lanes[0], z_near)
		_spawn_coin_line(lanes[1], z_near - 1.0, int(length / 2.2))
		if randf() < 0.45:
			_spawn_obstacle("barrier", lanes[2], z_near - 2.0)
	else:
		var tram2 := randf() < 0.5
		length = 14.0 if tram2 else 8.0
		var k2 := "tram" if tram2 else "bus"
		_spawn_obstacle(k2, lanes[0], z_near)
		_spawn_obstacle(k2, lanes[1], z_near)
		_spawn_coin_line(lanes[2], z_near - 1.0, int(length / 2.2))
	# изредка — шприц или шляпа в промежутке за рядом (свободны все три полосы)
	if randf() < PICKUP_CHANCE:
		_spawn_pickup("syringe" if randf() < 0.5 else "hat", randi() % 3, z_near - length - 7.0)
	return length + 14.0 + _speed * 0.7 + randf() * 10.0


func _spawn_logic(delta: float) -> void:
	_since += _speed * delta
	if _since >= _gap:
		var over := _since - _gap
		_since = over
		_gap = _spawn_row(SPAWN_Z + over)


# ================================================================= игрок
func _build_player() -> void:
	_player = Area3D.new()
	_player.monitorable = false
	_player.area_entered.connect(_on_player_area)
	_pcol = CollisionShape3D.new()
	_pshape = BoxShape3D.new()
	_pcol.shape = _pshape
	_player.add_child(_pcol)
	_set_hitbox(false)
	_pivot = _make_sprite(_tex_player, PLAYER_H)
	_pspr = _pivot.get_child(0) as Sprite3D
	_player.add_child(_pivot)
	add_child(_player)

	_blob = MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(1.5, 1.5)
	_blob.mesh = qm
	var bm := StandardMaterial3D.new()
	bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bm.albedo_texture = _tex_blob
	_blob.material_override = bm
	_blob.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_blob.rotation_degrees.x = -90.0
	_blob.position = Vector3(0, 0.04, 0)
	add_child(_blob)


func _set_hitbox(sliding: bool) -> void:
	if sliding:
		_pshape.size = Vector3(0.8, 0.8, 0.8)
		_pcol.position.y = 0.4
	else:
		_pshape.size = Vector3(0.8, 1.8, 0.8)
		_pcol.position.y = 0.9


func _move_lane(dir: int) -> void:
	if _state != State.RUN:
		return
	_lane = clampi(_lane + dir, 0, 2)


func _jump() -> void:
	if _state != State.RUN:
		return
	if _py <= 0.0 and _vy <= 0.0:
		_vy = JUMP_V
		_py = 0.001
		_slide_t = 0.0
		_set_hitbox(false)


func _slide() -> void:
	if _state != State.RUN:
		return
	if _py <= 0.0:
		_slide_t = SLIDE_TIME
		_set_hitbox(true)
	else:
		_vy = -28.0   # быстро вниз в воздухе


func _update_player(delta: float) -> void:
	var tx := (_lane - 1) * LANE_W
	_px = move_toward(_px, tx, LANE_SPEED * delta)
	if _py > 0.0 or _vy > 0.0:
		_vy -= GRAVITY * delta
		_py += _vy * delta
		if _py <= 0.0:
			_py = 0.0
			_vy = 0.0
	if _slide_t > 0.0:
		_slide_t -= delta
		if _slide_t <= 0.0:
			_set_hitbox(false)
	var on_ground := _py <= 0.0
	var sliding := _slide_t > 0.0
	var bob := 0.0
	var sx := 1.0
	var sy := 1.0
	var swing := 0.0
	if sliding:
		sx = 1.18
		sy = 0.45
	elif on_ground:
		bob = absf(sin(_run_t * 15.0)) * 0.16
		swing = sin(_run_t * 15.0) * 6.0
	var lean := clampf((tx - _px) * 8.0, -14.0, 14.0)
	_player.position = Vector3(_px, _py, 0.0)
	_pivot.position.y = bob
	_pspr.scale = Vector3(sx, sy, 1.0)
	_pspr.position.y = _ph * 0.5 * sy
	_pspr.rotation_degrees.z = swing + lean
	var bs := 1.0 / (1.0 + _py * 0.3)
	_blob.position.x = _px
	_blob.scale = Vector3(bs, bs, 1.0)


func _on_player_area(area: Area3D) -> void:
	if _state != State.RUN:
		return
	var kind: String = area.get_meta("kind", "")
	if kind == "coin":
		_coin_nodes.erase(area)
		area.queue_free()
		_coins_got += 1
		_sfx_pick.play()
	elif kind == "syringe":
		_coin_nodes.erase(area)
		area.queue_free()
		_sfx_pick.play()
		_start_eldz()
	elif kind == "hat":
		_coin_nodes.erase(area)
		area.queue_free()
		_sfx_pick.play()
		_imm_t = HAT_TIME
	elif kind == "hazard":
		if _imm_t > 0.0:
			return   # бессмертие от шляпы
		_crash()


# ================================================================= костюмы
func _build_costumes() -> void:
	for d in COSTUME_DEFS:
		var tex: Texture2D = load(d["sheet"])
		var cols: int = d["cols"]
		var rows: int = d["rows"]
		var fw := float(tex.get_width()) / float(cols)
		var fh := float(tex.get_height()) / float(rows)
		var height: float = float(d["width"]) * fh / fw
		var piv := _make_sprite(tex, height, cols, rows)
		piv.visible = false
		add_child(piv)
		var st: AudioStream = load(d["audio"])
		var ap := AudioStreamPlayer.new()
		ap.stream = st
		add_child(ap)
		var dur := st.get_length()
		if dur < 0.5:
			dur = float(d["frames"]) / COSTUME_FPS
		_costs.append({"pivot": piv, "spr": piv.get_child(0), "audio": ap, "frames": d["frames"], "dur": dur})


func _play_costume(i: int) -> void:
	_cur_cost = i
	_cost_t = 0.0
	var c: Dictionary = _costs[i]
	var piv: Node3D = c["pivot"]
	var x := clampf(_px * 0.6, -1.3, 1.3) if i == 1 else 0.0
	piv.position = Vector3(x, 0.0, 0.6)
	var spr: Sprite3D = c["spr"]
	spr.frame = 0
	piv.visible = true
	var ap: AudioStreamPlayer = c["audio"]
	ap.play()


func _update_costume(delta: float) -> void:
	if _cur_cost < 0:
		return
	_cost_t += delta
	var c: Dictionary = _costs[_cur_cost]
	var spr: Sprite3D = c["spr"]
	spr.frame = mini(int(_cost_t * COSTUME_FPS), int(c["frames"]) - 1)
	if _cost_t >= float(c["dur"]):
		var i := _cur_cost
		_cur_cost = -1
		var piv: Node3D = c["pivot"]
		piv.visible = false
		if i == 0:
			_start_run()      # костюм №1 закончился — снова обычный Меллстрой, играет музыка
		elif i == 1:
			_state = State.OVER
			_enable_buttons() # костюм №2 закончился — кнопки
			if _new_record:
				_play_costume(2)   # новый рекорд — «Ты просто босс»
				create_tween().tween_property(_lbl_boss, "modulate:a", 1.0, 0.4)


# ================================================================= фог
func _build_fog() -> void:
	_fog = _make_sprite(_tex_fog, FOG_H)
	_fog_spr = _fog.get_child(0) as Sprite3D
	_fog.position = Vector3(0, 0, FOG_Z)
	add_child(_fog)


func _animate_fog(delta: float) -> void:
	var tx := _px
	var tz := FOG_Z
	if _state == State.INTRO:
		tx = 0.0
	elif _state == State.DYING:
		tz = 3.0
	elif _state == State.OVER:
		tx = _px * 0.6
		tz = 1.2
	_fog.position.x = lerpf(_fog.position.x, tx, 1.0 - exp(-5.0 * delta))
	_fog.position.z = lerpf(_fog.position.z, tz, 1.0 - exp(-3.0 * delta))
	var ph := _t * 11.0
	_fog.position.y = absf(sin(ph)) * 0.25
	_fog_spr.rotation_degrees.z = sin(ph) * 5.0


# ================================================================= процесс
func _physics_process(delta: float) -> void:
	_t += delta
	match _state:
		State.LOBBY:
			_speed = LOBBY_SPEED
			_scroll_world(delta)
			_animate_lobby()
		State.INTRO:
			_speed = INTRO_SPEED
			_scroll_world(delta)
			_update_costume(delta)
		State.RUN:
			_run_t += delta
			_speed = minf(START_SPEED + ACCEL * _run_t, MAX_SPEED)
			_dist += _speed * delta
			_update_player(delta)
			_update_powerups(delta)
			_scroll_world(delta)
			_spawn_logic(delta)
			_animate_coins()
			_update_hud()
		State.DYING:
			_update_costume(delta)
		State.OVER:
			_update_costume(delta)   # футаж «Ты просто босс»
	_animate_fog(delta)
	_update_camera(delta)


func _scroll_world(delta: float) -> void:
	var dz := _speed * delta
	for s in _segs:
		s.position.z += dz
	var i := _obstacles.size() - 1
	while i >= 0:
		var o := _obstacles[i]
		o.position.z += dz
		if o.position.z > 24.0:
			o.queue_free()
			_obstacles.remove_at(i)
		i -= 1
	i = _coin_nodes.size() - 1
	while i >= 0:
		var c := _coin_nodes[i]
		c.position.z += dz
		if c.position.z > 14.0:
			c.queue_free()
			_coin_nodes.remove_at(i)
		i -= 1
	if _segs[0].position.z - SEG_LEN > 10.0:
		var old: Node3D = _segs.pop_front()
		old.queue_free()
		_add_segment(_segs.back().position.z - SEG_LEN)


func _animate_coins() -> void:
	for c in _coin_nodes:
		var spr: Sprite3D = c.get_meta("spr")
		var ph: float = c.get_meta("ph")
		var w := _t * 6.0 + ph
		var hh: float = float(c.get_meta("h", COIN_H))
		spr.position.y = hh * 0.5 + sin(w) * 0.08
		spr.rotation_degrees.z = sin(w * 0.8) * 12.0


func _update_camera(delta: float) -> void:
	var cx := _px * 0.5
	var sh := Vector3.ZERO
	if _shake > 0.0:
		sh = Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), 0.0) * _shake * 0.25
		_shake = maxf(0.0, _shake - delta * 1.2)
	_cam.position = CAM_POS + Vector3(cx, 0.0, 0.0) + sh
	_cam.look_at(CAM_LOOK + Vector3(cx * 0.9, 0.0, 0.0))


# ================================================================= ввод
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var te := event as InputEventScreenTouch
		_touch_active = te.pressed
		if te.pressed:
			_touch_start = te.position
	elif event is InputEventScreenDrag and _touch_active:
		var de := event as InputEventScreenDrag
		var d := de.position - _touch_start
		if d.length() >= 50.0:
			_touch_active = false
			if absf(d.x) > absf(d.y):
				_move_lane(1 if d.x > 0.0 else -1)
			elif d.y < 0.0:
				_jump()
			else:
				_slide()
	elif event is InputEventKey:
		var ke := event as InputEventKey
		if ke.pressed and not ke.echo:
			match ke.keycode:
				KEY_LEFT, KEY_A: _move_lane(-1)
				KEY_RIGHT, KEY_D: _move_lane(1)
				KEY_UP, KEY_W, KEY_SPACE: _jump()
				KEY_DOWN, KEY_S: _slide()


# ================================================================= звук
func _build_audio() -> void:
	_music = AudioStreamPlayer.new()
	var ms = load("res://assets/audio/submelltheme.mp3")
	if ms is AudioStreamMP3:
		ms.loop = true
	_music.stream = ms
	_music.volume_db = -3.0
	add_child(_music)
	_sfx_pick = AudioStreamPlayer.new()
	_sfx_pick.stream = load("res://assets/audio/pickup.wav")
	_sfx_pick.volume_db = -4.0
	add_child(_sfx_pick)
	_sfx_eldz = AudioStreamPlayer.new()
	_sfx_eldz.stream = load("res://assets/audio/eldz.mp3")
	add_child(_sfx_eldz)
	_sfx_hammam = AudioStreamPlayer.new()
	_sfx_hammam.stream = load("res://assets/audio/hammam.ogg")
	add_child(_sfx_hammam)
	_lobby_music = AudioStreamPlayer.new()
	_lobby_music.volume_db = -6.0
	_lobby_music.finished.connect(_next_lobby_track)
	add_child(_lobby_music)


# ================================================================= рекорд
func _score() -> int:
	return int(_dist) + _coins_got * 10


func _load_save() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://mellstroy.cfg") == OK:
		_best = int(cf.get_value("game", "best", 0))
		_wallet = int(cf.get_value("shop", "coins", 0))
		var ow = cf.get_value("shop", "owned", ["mellstroy"])
		_owned = []
		if ow is Array:
			for x in ow:
				_owned.append(str(x))
		_selected = str(cf.get_value("shop", "selected", "mellstroy"))
		_hammam_lvl = clampi(int(cf.get_value("shop", "hammam", 0)), 0, HAMMAM_MAX)
		var mo = cf.get_value("shop", "maps", ["city"])
		_maps_owned = []
		if mo is Array:
			for x in mo:
				_maps_owned.append(str(x))
		_map_id = str(cf.get_value("shop", "map", "city"))
	if not _maps_owned.has("city"):
		_maps_owned.append("city")
	for md in MAP_DEFS:
		if int(md["unlock"]) > 0 and _hammam_lvl >= int(md["unlock"]) and not _maps_owned.has(md["id"]):
			_maps_owned.append(md["id"])
	if not _maps_owned.has(_map_id):
		_map_id = "city"
	_map_style = str(_map_def(_map_id)["style"])
	if not _owned.has("mellstroy"):
		_owned.append("mellstroy")
	if not _owned.has(_selected):
		_selected = "mellstroy"


func _save_data() -> void:
	var cf := ConfigFile.new()
	cf.set_value("game", "best", _best)
	cf.set_value("shop", "coins", _wallet)
	cf.set_value("shop", "owned", _owned)
	cf.set_value("shop", "selected", _selected)
	cf.set_value("shop", "hammam", _hammam_lvl)
	cf.set_value("shop", "maps", _maps_owned)
	cf.set_value("shop", "map", _map_id)
	cf.save("user://mellstroy.cfg")


# ================================================================= лобби и персонажи
func _char_index(id: String) -> int:
	for i in CHAR_DEFS.size():
		if CHAR_DEFS[i]["id"] == id:
			return i
	return 0


func _apply_character() -> void:
	var d: Dictionary = CHAR_DEFS[_char_index(_selected)]
	var tex: Texture2D = _char_tex[d["id"]]
	_ph = float(d["h"])
	_pspr.frame = 0
	_pspr.hframes = 1
	_pspr.vframes = 1
	_pspr.texture = tex
	_pspr.pixel_size = _ph / float(tex.get_height())
	_pspr.position.y = _ph * 0.5
	if _lobby_btn != null:
		_lobby_btn.texture_normal = tex
		_lbl_lobby_name.text = d["name"]


func _animate_lobby() -> void:
	if _lobby_btn == null:
		return
	_lobby_btn.pivot_offset = _lobby_btn.size * 0.5
	_lobby_btn.scale = Vector2.ONE * (1.0 + sin(_t * 2.2) * 0.025)
	_lobby_btn.rotation_degrees = sin(_t * 1.4) * 1.5


func _update_wallet_labels() -> void:
	if _lbl_wallet != null:
		_lbl_wallet.text = " %d" % _wallet
	if _lbl_shop_wallet != null:
		_lbl_shop_wallet.text = " %d" % _wallet
	if _lbl_ham_wallet != null:
		_lbl_ham_wallet.text = " %d" % _wallet


func _coin_icon(w: float, h: float) -> TextureRect:
	var t := TextureRect.new()
	t.texture = _tex_coin
	t.custom_minimum_size = Vector2(w, h)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t


func _build_lobby(root: Control, top: float) -> void:
	_lobby = Control.new()
	_lobby.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lobby.visible = false
	root.add_child(_lobby)
	_lobby.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.22)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lobby.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# чекушки сверху справа
	var wb := HBoxContainer.new()
	wb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wb.alignment = BoxContainer.ALIGNMENT_END
	_lobby.add_child(wb)
	wb.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	wb.offset_left = 40.0
	wb.offset_right = -40.0
	wb.offset_top = top + 24.0
	wb.offset_bottom = top + 124.0
	wb.add_child(_coin_icon(60, 100))
	_lbl_wallet = _label("0", 68)
	wb.add_child(_lbl_wallet)

	# главный персонаж по центру
	var center := CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lobby.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_top = 560.0
	center.offset_bottom = -470.0
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_theme_constant_override("separation", 10)
	center.add_child(vb)
	_lbl_lobby_name = _label("", 76, Color(1.0, 0.85, 0.2))
	vb.add_child(_lbl_lobby_name)
	var stage := Control.new()
	stage.custom_minimum_size = Vector2(720, 640)
	stage.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(stage)
	var sh := TextureRect.new()
	sh.texture = _tex_blob
	sh.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	sh.stretch_mode = TextureRect.STRETCH_SCALE
	sh.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stage.add_child(sh)
	sh.position = Vector2(80, 520)
	sh.size = Vector2(560, 130)
	_lobby_btn = TextureButton.new()
	_lobby_btn.ignore_texture_size = true
	_lobby_btn.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
	stage.add_child(_lobby_btn)
	_lobby_btn.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_lobby_btn.pressed.connect(_open_shop)
	vb.add_child(_label("нажми на персонажа — выбор и покупка", 40))

	# кнопки «Хаммам» и «Карты»
	var rb := CenterContainer.new()
	rb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lobby.add_child(rb)
	rb.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	rb.offset_top = -440.0
	rb.offset_bottom = -290.0
	var rhb := HBoxContainer.new()
	rhb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rhb.add_theme_constant_override("separation", 30)
	rb.add_child(rhb)
	_btn_ham = Button.new()
	_btn_ham.text = "ХАММАМ"
	_style_btn(_btn_ham, Color(0.12, 0.45, 0.62), Vector2(375, 130), 50)
	_btn_ham.pressed.connect(_open_hammam)
	rhb.add_child(_btn_ham)
	_btn_maps = Button.new()
	_btn_maps.text = "КАРТЫ"
	_style_btn(_btn_maps, Color(0.45, 0.30, 0.65), Vector2(375, 130), 50)
	_btn_maps.pressed.connect(_open_maps)
	rhb.add_child(_btn_maps)

	# кнопка «Играть»
	var pb := CenterContainer.new()
	pb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lobby.add_child(pb)
	pb.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	pb.offset_top = -270.0
	pb.offset_bottom = -100.0
	_btn_play = Button.new()
	_btn_play.text = "ИГРАТЬ"
	_style_btn(_btn_play, Color(0.15, 0.62, 0.25))
	_btn_play.pressed.connect(_on_play)
	pb.add_child(_btn_play)


func _build_shop(root: Control, top: float) -> void:
	_shop = Control.new()
	_shop.visible = false
	root.add_child(_shop)
	_shop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.78)
	_shop.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_shop.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_top = top * 0.5
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_theme_constant_override("separation", 22)
	center.add_child(vb)
	vb.add_child(_label("ПЕРСОНАЖИ", 96, Color(1.0, 0.85, 0.2)))
	var wr := HBoxContainer.new()
	wr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wr.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(wr)
	wr.add_child(_coin_icon(48, 80))
	_lbl_shop_wallet = _label("0", 64)
	wr.add_child(_lbl_shop_wallet)
	_shop_rows = VBoxContainer.new()
	_shop_rows.add_theme_constant_override("separation", 20)
	vb.add_child(_shop_rows)
	_lbl_shop_msg = _label(" ", 48, Color(1.0, 0.45, 0.35))
	vb.add_child(_lbl_shop_msg)
	var back := Button.new()
	back.text = "НАЗАД"
	_style_btn(back, Color(0.70, 0.18, 0.18))
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	back.pressed.connect(_close_shop)
	vb.add_child(back)


func _char_row(i: int) -> Control:
	var d: Dictionary = CHAR_DEFS[i]
	var id: String = d["id"]
	var price: int = d["price"]
	var owned := _owned.has(id)
	var chosen := _selected == id
	var pc := PanelContainer.new()
	var ps := StyleBoxFlat.new()
	ps.bg_color = Color(0.20, 0.17, 0.05, 0.95) if chosen else Color(0.10, 0.12, 0.20, 0.95)
	ps.set_corner_radius_all(28)
	ps.set_border_width_all(5)
	ps.border_color = Color(1.0, 0.85, 0.2) if chosen else Color(1, 1, 1, 0.35)
	ps.set_content_margin_all(18)
	pc.add_theme_stylebox_override("panel", ps)
	pc.custom_minimum_size = Vector2(980, 0)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 24)
	pc.add_child(hb)
	var pic := TextureRect.new()
	pic.texture = _char_tex[id]
	pic.custom_minimum_size = Vector2(190, 190)
	pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	hb.add_child(pic)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_child(info)
	var nm := _label(d["name"], 46)
	nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	nm.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	nm.custom_minimum_size = Vector2(330, 0)
	info.add_child(nm)
	if owned:
		var st := _label("Основной" if price == 0 else "Куплен", 40, Color(0.5, 1.0, 0.5))
		st.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		info.add_child(st)
	else:
		var pr := HBoxContainer.new()
		pr.add_child(_coin_icon(34, 56))
		var pl := _label(" %d" % price, 52, Color(1.0, 0.85, 0.2))
		pl.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		pr.add_child(pl)
		info.add_child(pr)
	var btn := Button.new()
	var col := Color(0.15, 0.62, 0.25)
	if chosen:
		btn.text = "ВЫБРАН"
		btn.disabled = true
		col = Color(0.75, 0.58, 0.05)
	elif owned:
		btn.text = "ВЫБРАТЬ"
	else:
		btn.text = "КУПИТЬ"
		col = Color(0.20, 0.40, 0.80) if _wallet >= price else Color(0.40, 0.40, 0.44)
	_style_btn(btn, col, Vector2(300, 120), 46)
	btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	btn.pressed.connect(_on_char_action.bind(i))
	hb.add_child(btn)
	return pc


func _refresh_shop() -> void:
	for c in _shop_rows.get_children():
		_shop_rows.remove_child(c)
		c.queue_free()
	for i in CHAR_DEFS.size():
		_shop_rows.add_child(_char_row(i))
	_update_wallet_labels()


func _open_shop() -> void:
	if _state != State.LOBBY:
		return
	_lbl_shop_msg.text = " "
	_refresh_shop()
	_shop.visible = true


func _close_shop() -> void:
	_shop.visible = false


func _on_char_action(i: int) -> void:
	var d: Dictionary = CHAR_DEFS[i]
	var id: String = d["id"]
	var price: int = d["price"]
	_lbl_shop_msg.text = " "
	if _owned.has(id):
		_selected = id
	elif _wallet >= price:
		_wallet -= price
		_owned.append(id)
		_selected = id
		_sfx_pick.play()
	else:
		_lbl_shop_msg.text = "Не хватает чекушек: нужно %d" % price
		return
	_apply_character()
	_save_data()
	_refresh_shop()


# ================================================================= интерфейс
func _label(text: String, size: int, col: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", int(size * 0.12))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _style_btn(b: Button, col: Color, size: Vector2 = Vector2(780, 150), fsize: int = 60) -> void:
	for st in ["normal", "hover", "pressed", "focus", "disabled"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = col.lightened(0.18) if st == "pressed" else col
		sb.set_corner_radius_all(32)
		sb.set_border_width_all(6)
		sb.border_color = Color.WHITE
		sb.shadow_color = Color(0, 0, 0, 0.45)
		sb.shadow_size = 14
		sb.shadow_offset = Vector2(0, 6)
		b.add_theme_stylebox_override(st, sb)
	b.add_theme_font_size_override("font_size", fsize)
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_disabled_color", Color.WHITE)
	b.custom_minimum_size = size


## Отступ сверху под вырез/чёлку экрана (в единицах viewport).
func _safe_top() -> float:
	var win := DisplayServer.window_get_size()
	if win.x <= 0:
		return 24.0
	var safe := DisplayServer.get_display_safe_area()
	var k := get_viewport().get_visible_rect().size.x / float(win.x)
	return maxf(24.0, float(safe.position.y) * k)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var top := _safe_top()

	# мягкая виньетка по краям экрана
	var vg := Gradient.new()
	vg.colors = PackedColorArray([Color(0, 0, 0, 0.0), Color(0, 0, 0, 0.0), Color(0, 0, 0, 0.5)])
	vg.offsets = PackedFloat32Array([0.0, 0.6, 1.0])
	var vt := GradientTexture2D.new()
	vt.gradient = vg
	vt.fill = GradientTexture2D.FILL_RADIAL
	vt.fill_from = Vector2(0.5, 0.5)
	vt.fill_to = Vector2(1.0, 1.0)
	vt.width = 256
	vt.height = 256
	var vr := TextureRect.new()
	vr.texture = vt
	vr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vr.stretch_mode = TextureRect.STRETCH_SCALE
	vr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(vr)
	vr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# HUD: счёт слева, чекушки справа
	_hud = HBoxContainer.new()
	_hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_hud)
	_hud.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_hud.offset_left = 40.0
	_hud.offset_right = -40.0
	_hud.offset_top = top + 24.0
	_hud.offset_bottom = top + 124.0
	_lbl_score = _label("0", 68)
	_lbl_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	_lbl_score.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_hud.add_child(_lbl_score)
	var icon := TextureRect.new()
	icon.texture = _tex_coin
	icon.custom_minimum_size = Vector2(60, 100)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud.add_child(icon)
	_lbl_coins = _label("0", 68)
	_hud.add_child(_lbl_coins)

	# таймеры бонусов под счётом
	_pu_box = VBoxContainer.new()
	_pu_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_pu_box.visible = false
	root.add_child(_pu_box)
	_pu_box.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_pu_box.offset_left = 40.0
	_pu_box.offset_top = top + 130.0
	_row_el = HBoxContainer.new()
	_row_el.visible = false
	_pu_box.add_child(_row_el)
	_row_el.add_child(_pu_icon(_tex_syringe, 96, 56))
	_lbl_el = _label("0", 52)
	_row_el.add_child(_lbl_el)
	_row_imm = HBoxContainer.new()
	_row_imm.visible = false
	_pu_box.add_child(_row_imm)
	_row_imm.add_child(_pu_icon(_tex_hat, 56, 56))
	_lbl_imm = _label("0", 52)
	_row_imm.add_child(_lbl_imm)

	# заголовок в начале
	_title = _label("МЕЛЛСТРОЙ\nПОБЕГ ОТ ФОГА", 100, Color(1.0, 0.85, 0.2))
	root.add_child(_title)
	_title.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_title.offset_top = top + 220.0
	_title.offset_bottom = top + 520.0

	# Game Over
	_over = Control.new()
	_over.visible = false
	root.add_child(_over)
	_over.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	_over.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_over.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 26)
	center.add_child(vb)
	vb.add_child(_label("GAME OVER", 130, Color(1.0, 0.25, 0.2)))
	_lbl_final = _label("", 70)
	vb.add_child(_lbl_final)
	_lbl_over_coins = _label("", 56)
	vb.add_child(_lbl_over_coins)
	_lbl_best = _label("", 56, Color(1.0, 0.85, 0.2))
	vb.add_child(_lbl_best)
	_lbl_record = _label("НОВЫЙ РЕКОРД!", 84, Color(1.0, 0.85, 0.2))
	_lbl_record.visible = false
	vb.add_child(_lbl_record)
	_lbl_boss = _label("ТЫ ПРОСТО БОСС", 100, Color(1.0, 0.35, 0.25))
	_lbl_boss.visible = false
	_lbl_boss.modulate.a = 0.0
	vb.add_child(_lbl_boss)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 30)
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(gap)
	_btn_box = VBoxContainer.new()
	_btn_box.add_theme_constant_override("separation", 28)
	_btn_box.modulate.a = 0.0
	vb.add_child(_btn_box)
	_btn_again = Button.new()
	_btn_again.text = "ИГРАТЬ СНОВА"
	_style_btn(_btn_again, Color(0.15, 0.62, 0.25))
	_btn_again.disabled = true
	_btn_again.pressed.connect(_on_again)
	_btn_box.add_child(_btn_again)
	_btn_quit = Button.new()
	_btn_quit.text = "ВЫЙТИ"
	_style_btn(_btn_quit, Color(0.70, 0.18, 0.18))
	_btn_quit.disabled = true
	_btn_quit.pressed.connect(_on_quit)
	_btn_box.add_child(_btn_quit)

	_build_lobby(root, top)
	_build_shop(root, top)
	_build_hammam(root, top)
	_build_maps(root, top)
	_build_drop(root)


func _update_hud() -> void:
	_lbl_score.text = "%d м" % _score()
	_lbl_coins.text = " %d" % _coins_got


func _show_over_title() -> void:
	_update_hud()
	_lbl_final.text = "Счёт: %d" % _score()
	_lbl_over_coins.text = "Чекушек: %d" % _coins_got
	_lbl_best.text = "Рекорд: %d" % _best
	_lbl_record.visible = _new_record
	_lbl_boss.visible = _new_record
	_over.modulate.a = 0.0
	_over.visible = true
	create_tween().tween_property(_over, "modulate:a", 1.0, 0.35)


func _enable_buttons() -> void:
	_btn_again.disabled = false
	_btn_quit.disabled = false
	create_tween().tween_property(_btn_box, "modulate:a", 1.0, 0.3)


func _on_again() -> void:
	_lobby_track = (_lobby_track + 1) % LOBBY_TRACKS.size()
	get_tree().reload_current_scene()


func _on_quit() -> void:
	get_tree().quit()


# ================================================================= версия 1.1: бонусы
func _pu_icon(tex: Texture2D, w: float, h: float) -> TextureRect:
	var t := TextureRect.new()
	t.texture = tex
	t.custom_minimum_size = Vector2(w, h)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t


## Радужный фильтр на 3D-картинку (ниже интерфейса, поэтому кнопки и счёт не меняются).
func _build_rainbow() -> void:
	_rainbow = CanvasLayer.new()
	_rainbow.layer = 5
	_rainbow.visible = false
	add_child(_rainbow)
	var sh := Shader.new()
	sh.code = RAINBOW_SHADER
	var mat := ShaderMaterial.new()
	mat.shader = sh
	var r := ColorRect.new()
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.material = mat
	_rainbow.add_child(r)
	r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _spawn_pickup(kind: String, lane: int, z: float) -> void:
	var a := Area3D.new()
	a.monitoring = false
	a.set_meta("kind", kind)
	var ph := SYRINGE_H if kind == "syringe" else HAT_H
	var tex: Texture2D = _tex_syringe if kind == "syringe" else _tex_hat
	var piv := _make_sprite(tex, ph)
	a.add_child(piv)
	a.set_meta("spr", piv.get_child(0))
	a.set_meta("ph", randf() * TAU)
	a.set_meta("h", ph)
	var col := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.3, ph, 0.8)
	col.shape = bs
	col.position.y = ph * 0.5
	a.add_child(col)
	a.position = Vector3((lane - 1) * LANE_W, 0.95 - ph * 0.5, z)
	add_child(a)
	_coin_nodes.append(a)


## Шприц: песня + футаж вместо персонажа + радужная графика на 12 секунд.
func _start_eldz() -> void:
	_el_t = SYRINGE_TIME
	_music.stream_paused = true
	_sfx_eldz.stop()
	_sfx_eldz.play()
	_pspr.frame = 0
	_pspr.texture = _tex_el
	_pspr.hframes = EL_COLS
	_pspr.vframes = EL_ROWS
	_pspr.frame = 0
	var fh := float(_tex_el.get_height()) / float(EL_ROWS)
	_ph = EL_H
	_pspr.pixel_size = EL_H / fh
	_rainbow.visible = true


func _end_eldz() -> void:
	_el_t = 0.0
	_sfx_eldz.stop()
	_music.stream_paused = false
	_rainbow.visible = false
	_apply_character()


func _end_powerups() -> void:
	if _el_t > 0.0:
		_end_eldz()
	_imm_t = 0.0
	_pspr.modulate = Color.WHITE
	_pu_box.visible = false


func _inside_hazard() -> bool:
	for ar in _player.get_overlapping_areas():
		if ar.get_meta("kind", "") == "hazard":
			return true
	return false


func _update_powerups(delta: float) -> void:
	if _el_t > 0.0:
		_el_t -= delta
		if _el_t <= 0.0:
			_end_eldz()
		else:
			_pspr.frame = int((SYRINGE_TIME - _el_t) * EL_FPS) % EL_FRAMES
	if _imm_t > 0.0:
		_imm_t -= delta
		if _imm_t <= 0.0 and _inside_hazard():
			_imm_t = 0.05   # шляпа не гаснет, пока персонаж внутри препятствия
		var fast := 18.0 if _imm_t < 2.0 else 8.0
		var k := 0.5 + 0.5 * sin(_run_t * fast)
		_pspr.modulate = Color(1.0, 0.85 + 0.15 * k, 0.35 + 0.65 * k, 1.0)
		if _imm_t <= 0.0:
			_pspr.modulate = Color.WHITE
	_row_el.visible = _el_t > 0.0
	_row_imm.visible = _imm_t > 0.0
	_lbl_el.text = " %d" % int(ceil(_el_t))
	_lbl_imm.text = " %d" % int(ceil(_imm_t))


# ================================================================= карты
func _map_def(id: String) -> Dictionary:
	for d: Dictionary in MAP_DEFS:
		if d["id"] == id:
			return d
	return MAP_DEFS[0]


func _apply_map_env() -> void:
	var d := _map_def(_map_id)
	_sky_mat.sky_top_color = d["sky_top"]
	_sky_mat.sky_horizon_color = d["horizon"]
	_sky_mat.ground_horizon_color = d["horizon"]
	_sky_mat.ground_bottom_color = d["ground"]
	_env.fog_light_color = d["horizon"]
	_env.fog_density = d["fog_density"]
	_env.ambient_light_color = d["ambient"]
	_env.ambient_light_energy = d["ambient_e"]
	_sun.light_color = d["sun"]
	_sun.light_energy = d["sun_e"]


## Смена карты: перекрашивает небо/свет и заново собирает дорогу и дома.
func _apply_map() -> void:
	_map_style = str(_map_def(_map_id)["style"])
	_apply_map_env()
	for sg in _segs:
		sg.queue_free()
	_segs.clear()
	for i in SEG_COUNT:
		_add_segment(20.0 - i * SEG_LEN)


func _map_preview(d: Dictionary) -> Texture2D:
	var id: String = d["id"]
	if _map_prev.has(id):
		return _map_prev[id]
	var tex: Texture2D = null
	var path: String = d["preview"]
	if path != "" and ResourceLoader.exists(path):
		tex = load(path)
	if tex == null:
		tex = _gen_map_preview(d)
	_map_prev[id] = tex
	return tex


## Запасная картинка карты (рисуется кодом), если файла-превью нет.
func _gen_map_preview(d: Dictionary) -> Texture2D:
	var img := Image.create_empty(256, 256, false, Image.FORMAT_RGBA8)
	var top: Color = d["sky_top"]
	var hor: Color = d["horizon"]
	for y in 256:
		var t := minf(float(y) / 150.0, 1.0)
		img.fill_rect(Rect2i(0, y, 256, 1), top.lerp(hor, t))
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(str(d["id"]))
	var x := 0
	while x < 256:
		var w := rng.randi_range(26, 46)
		var h := rng.randi_range(50, 130)
		var bc := hor.darkened(0.45)
		img.fill_rect(Rect2i(x, 160 - h, w, h), bc)
		for wy in range(160 - h + 8, 154, 14):
			for wx in range(x + 5, x + w - 6, 10):
				img.fill_rect(Rect2i(wx, wy, 5, 7), bc.lightened(0.35))
		x += w + rng.randi_range(2, 8)
	img.fill_rect(Rect2i(0, 160, 256, 96), Color(0.36, 0.37, 0.40))
	for y in range(160, 256):
		var hw := int(lerpf(10.0, 118.0, float(y - 160) / 96.0))
		img.fill_rect(Rect2i(128 - hw, y, hw * 2, 1), Color(0.16, 0.16, 0.18))
	return ImageTexture.create_from_image(img)


func _build_maps(root: Control, top: float) -> void:
	_maps = Control.new()
	_maps.visible = false
	root.add_child(_maps)
	_maps.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.78)
	_maps.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_maps.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_top = top * 0.5
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_theme_constant_override("separation", 22)
	center.add_child(vb)
	vb.add_child(_label("КАРТЫ", 96, Color(1.0, 0.85, 0.2)))
	_map_rows = VBoxContainer.new()
	_map_rows.add_theme_constant_override("separation", 20)
	vb.add_child(_map_rows)
	_lbl_maps_msg = _label(" ", 48, Color(1.0, 0.45, 0.35))
	vb.add_child(_lbl_maps_msg)
	var back := Button.new()
	back.text = "НАЗАД"
	_style_btn(back, Color(0.70, 0.18, 0.18))
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	back.pressed.connect(_close_maps)
	vb.add_child(back)


func _map_row(i: int) -> Control:
	var d: Dictionary = MAP_DEFS[i]
	var id: String = d["id"]
	var owned := _maps_owned.has(id)
	var chosen := _map_id == id
	var pc := PanelContainer.new()
	var ps := StyleBoxFlat.new()
	ps.bg_color = Color(0.20, 0.17, 0.05, 0.95) if chosen else Color(0.10, 0.12, 0.20, 0.95)
	ps.set_corner_radius_all(28)
	ps.set_border_width_all(5)
	ps.border_color = Color(1.0, 0.85, 0.2) if chosen else Color(1, 1, 1, 0.35)
	ps.set_content_margin_all(18)
	pc.add_theme_stylebox_override("panel", ps)
	pc.custom_minimum_size = Vector2(980, 0)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 24)
	pc.add_child(hb)
	var pic := TextureRect.new()
	pic.texture = _map_preview(d)
	pic.custom_minimum_size = Vector2(230, 230)
	pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	hb.add_child(pic)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_child(info)
	var nm := _label(str(d["name"]), 52)
	nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	info.add_child(nm)
	var st: Label
	if owned:
		st = _label("Открыта", 40, Color(0.5, 1.0, 0.5))
	else:
		st = _label("Хаммам: уровень %d" % int(d["unlock"]), 40, Color(1.0, 0.85, 0.2))
	st.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	info.add_child(st)
	var btn := Button.new()
	var col := Color(0.15, 0.62, 0.25)
	if chosen:
		btn.text = "ВЫБРАНА"
		btn.disabled = true
		col = Color(0.75, 0.58, 0.05)
	elif owned:
		btn.text = "ВЫБРАТЬ"
	else:
		btn.text = "ЗАКРЫТА"
		btn.disabled = true
		col = Color(0.40, 0.40, 0.44)
	_style_btn(btn, col, Vector2(300, 120), 46)
	btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	btn.pressed.connect(_on_map_action.bind(i))
	hb.add_child(btn)
	return pc


func _refresh_maps() -> void:
	for c in _map_rows.get_children():
		_map_rows.remove_child(c)
		c.queue_free()
	for i in MAP_DEFS.size():
		_map_rows.add_child(_map_row(i))


func _open_maps() -> void:
	if _state != State.LOBBY:
		return
	_lbl_maps_msg.text = " "
	_refresh_maps()
	_maps.visible = true


func _close_maps() -> void:
	_maps.visible = false


func _on_map_action(i: int) -> void:
	var d: Dictionary = MAP_DEFS[i]
	var id: String = d["id"]
	if not _maps_owned.has(id) or _map_id == id:
		return
	_map_id = id
	_save_data()
	_apply_map()
	_refresh_maps()


func _build_drop(root: Control) -> void:
	_drop = Control.new()
	_drop.visible = false
	root.add_child(_drop)
	_drop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.88)
	_drop.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_drop.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_theme_constant_override("separation", 26)
	center.add_child(vb)
	vb.add_child(_label("НОВАЯ КАРТА!", 100, Color(1.0, 0.85, 0.2)))
	_drop_pic = TextureRect.new()
	_drop_pic.custom_minimum_size = Vector2(620, 620)
	_drop_pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_drop_pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_drop_pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(_drop_pic)
	_lbl_drop_name = _label("", 90)
	vb.add_child(_lbl_drop_name)
	var ok := Button.new()
	ok.text = "ОТЛИЧНО"
	_style_btn(ok, Color(0.15, 0.62, 0.25))
	ok.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ok.pressed.connect(_close_drop)
	vb.add_child(ok)


func _show_drop(d: Dictionary) -> void:
	_drop_pic.texture = _map_preview(d)
	_lbl_drop_name.text = str(d["name"])
	_drop.visible = true
	_drop_pic.pivot_offset = _drop_pic.custom_minimum_size * 0.5
	_drop_pic.scale = Vector2(0.1, 0.1)
	var tw := create_tween()
	tw.tween_property(_drop_pic, "scale", Vector2.ONE, 0.7).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_sfx_pick.play()


func _close_drop() -> void:
	_drop.visible = false


# ================================================================= хаммам
func _hammam_price(level: int) -> int:
	return HAMMAM_BASE + HAMMAM_STEP * (level - 1)


func _build_hammam(root: Control, top: float) -> void:
	_hammam = Control.new()
	_hammam.visible = false
	root.add_child(_hammam)
	_hammam.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.82)
	_hammam.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hammam.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_top = top * 0.5
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_theme_constant_override("separation", 14)
	center.add_child(vb)
	_lbl_ham_title = _label("", 80, Color(1.0, 0.85, 0.2))
	vb.add_child(_lbl_ham_title)
	var wr := HBoxContainer.new()
	wr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wr.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(wr)
	wr.add_child(_coin_icon(48, 72))
	_lbl_ham_wallet = _label("0", 60)
	wr.add_child(_lbl_ham_wallet)
	var frame := PanelContainer.new()
	var fs := StyleBoxFlat.new()
	fs.bg_color = Color(0.05, 0.06, 0.10, 0.95)
	fs.set_corner_radius_all(26)
	fs.set_border_width_all(5)
	fs.border_color = Color(1, 1, 1, 0.6)
	fs.set_content_margin_all(10)
	frame.add_theme_stylebox_override("panel", fs)
	frame.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(frame)
	_ham_pic = TextureRect.new()
	_ham_pic.custom_minimum_size = Vector2(430, 740)
	_ham_pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_ham_pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	frame.add_child(_ham_pic)
	_lbl_ham_cur = _label("", 40, Color(0.8, 0.9, 1.0))
	vb.add_child(_lbl_ham_cur)
	_ham_price_row = HBoxContainer.new()
	_ham_price_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ham_price_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(_ham_price_row)
	_ham_price_row.add_child(_coin_icon(48, 72))
	_lbl_ham_price = _label("", 64, Color(1.0, 0.85, 0.2))
	_ham_price_row.add_child(_lbl_ham_price)
	_btn_upgrade = Button.new()
	_btn_upgrade.text = "УЛУЧШИТЬ"
	_style_btn(_btn_upgrade, Color(0.15, 0.62, 0.25), Vector2(780, 140))
	_btn_upgrade.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_btn_upgrade.pressed.connect(_on_upgrade)
	vb.add_child(_btn_upgrade)
	_lbl_ham_msg = _label(" ", 46, Color(1.0, 0.45, 0.35))
	vb.add_child(_lbl_ham_msg)
	var back := Button.new()
	back.text = "НАЗАД"
	_style_btn(back, Color(0.70, 0.18, 0.18), Vector2(780, 130))
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	back.pressed.connect(_close_hammam)
	vb.add_child(back)


func _refresh_hammam() -> void:
	var maxed := _hammam_lvl >= HAMMAM_MAX
	var show_lvl := HAMMAM_MAX if maxed else _hammam_lvl + 1
	_lbl_ham_title.text = "ХАММАМ УРОВЕНЬ %d" % show_lvl
	var t: Texture2D = load("res://assets/hammam/%d.png" % show_lvl)
	_ham_pic.texture = t
	_lbl_ham_cur.text = "Построено уровней: %d из %d" % [_hammam_lvl, HAMMAM_MAX]
	_ham_price_row.visible = not maxed
	_btn_upgrade.visible = not maxed
	if maxed:
		_lbl_ham_msg.text = "Максимальный уровень!"
	else:
		var price := _hammam_price(show_lvl)
		_lbl_ham_price.text = " %d" % price
		var col := Color(0.15, 0.62, 0.25) if _wallet >= price else Color(0.40, 0.40, 0.44)
		_style_btn(_btn_upgrade, col, Vector2(780, 140))
	_update_wallet_labels()


func _open_hammam() -> void:
	if _state != State.LOBBY:
		return
	_lbl_ham_msg.text = " "
	_refresh_hammam()
	_hammam.visible = true
	_sfx_hammam.play()


func _close_hammam() -> void:
	_hammam.visible = false


func _on_upgrade() -> void:
	if _hammam_lvl >= HAMMAM_MAX:
		return
	var nxt := _hammam_lvl + 1
	var price := _hammam_price(nxt)
	if _wallet < price:
		_lbl_ham_msg.text = "Не хватает чекушек: нужно %d" % price
		return
	_wallet -= price
	_hammam_lvl = nxt
	_sfx_hammam.play()
	var unlocked := {}
	for md: Dictionary in MAP_DEFS:
		if int(md["unlock"]) > 0 and int(md["unlock"]) == _hammam_lvl and not _maps_owned.has(md["id"]):
			_maps_owned.append(md["id"])
			unlocked = md
	_save_data()
	_lbl_ham_msg.text = " "
	_refresh_hammam()
	if not unlocked.is_empty():
		_show_drop(unlocked)


# ================================================================= музыка лобби
func _play_lobby_music() -> void:
	var n := LOBBY_TRACKS.size()
	for i in n:
		var idx := (_lobby_track + i) % n
		var path: String = LOBBY_TRACKS[idx]
		if ResourceLoader.exists(path):
			var st: AudioStream = load(path)
			if st != null:
				_lobby_track = idx
				_lobby_music.stream = st
				_lobby_music.play()
				return


func _next_lobby_track() -> void:
	if _state != State.LOBBY:
		return
	_lobby_track = (_lobby_track + 1) % LOBBY_TRACKS.size()
	_play_lobby_music()


# ================================================================= карта «Мурино»
func _fill_murino(s: Node3D) -> void:
	_box(s, Vector3(ROAD_HALF * 2.0, 0.4, SEG_LEN + 0.05), Vector3(0, -0.2, -SEG_LEN * 0.5), _tex_mat(_tex_road, Vector3(ROAD_HALF * 2.0 / 2.0, SEG_LEN / 2.0, 1.0), 0.8))
	var white := _mat(Color(0.88, 0.88, 0.84))
	for sx: float in [-0.5, 0.5]:
		for k in 5:
			_box(s, Vector3(0.14, 0.02, 4.0), Vector3(sx * LANE_W, 0.01, -4.0 - k * 8.0), white)
	# пешеходный переход
	if randf() < 0.4:
		var zz := randf_range(-32.0, -10.0)
		for k in 7:
			_box(s, Vector3(0.55, 0.02, 3.2), Vector3(-3.0 + k * 1.0, 0.012, zz), white)
	for side: int in [-1, 1]:
		# широкий тротуар и забор двора
		_box(s, Vector3(3.0, 0.3, SEG_LEN + 0.05), Vector3(side * (ROAD_HALF + 1.5), 0.15, -SEG_LEN * 0.5), _tex_mat(_tex_walk, Vector3(1.5, SEG_LEN / 2.0, 1.0), 0.9))
		_box(s, Vector3(0.1, 1.0, SEG_LEN + 0.05), Vector3(side * (ROAD_HALF + 3.1), 0.5, -SEG_LEN * 0.5), _mat(Color(0.20, 0.34, 0.26), 0.0, 0.7, 0.2))
		# ближний ряд высоток
		var zc := 0.0
		while zc > -SEG_LEN + 8.0:
			var d := minf(randf_range(15.0, 21.0), SEG_LEN + zc)
			var w := randf_range(11.0, 16.0)
			var h := randf_range(36.0, 70.0)
			_building(s, Vector3(side * (ROAD_HALF + 6.5 + w * 0.5), h * 0.5, zc - d * 0.5), Vector3(w, h, d), side, true)
			zc -= d + randf_range(6.0, 12.0)
		# дальний ряд — просветы между ближними башнями
		var fw := randf_range(12.0, 16.0)
		var fh := randf_range(50.0, 85.0)
		var fd := randf_range(16.0, 22.0)
		_building(s, Vector3(side * (ROAD_HALF + 36.0), fh * 0.5, randf_range(-30.0, -12.0)), Vector3(fw, fh, fd), side, true)
		# фонари
		for zl: float in [-6.0, -26.0]:
			_lamp_murino(s, Vector3(side * (ROAD_HALF + 0.5), 0.0, zl), side)
		# берёзы и машины во дворе
		_birch(s, Vector3(side * (ROAD_HALF + 3.8), 0.0, randf_range(-36.0, -4.0)))
		_birch(s, Vector3(side * (ROAD_HALF + 4.4), 0.0, randf_range(-36.0, -4.0)))
		_parked_car(s, Vector3(side * (ROAD_HALF + 4.6), 0.0, randf_range(-36.0, -6.0)))
		_parked_car(s, Vector3(side * (ROAD_HALF + 4.6), 0.0, randf_range(-36.0, -6.0)))
	# стройка на заднем плане: башенный кран
	if randf() < 0.4:
		_crane(s, Vector3((1 if randf() < 0.5 else -1) * (ROAD_HALF + 26.0), 0.0, randf_range(-34.0, -8.0)))


func _lamp_murino(parent: Node3D, pos: Vector3, side: int) -> void:
	var metal := _mat(Color(0.30, 0.32, 0.36), 0.0, 0.4, 0.6)
	_cyl(parent, 0.08, 0.12, 7.0, pos + Vector3(0, 3.5, 0), metal)
	_box(parent, Vector3(1.8, 0.10, 0.10), pos + Vector3(-side * 0.9, 7.0, 0), metal)
	_box(parent, Vector3(0.7, 0.12, 0.35), pos + Vector3(-side * 1.7, 6.92, 0), _mat(Color(0.85, 0.95, 1.0), 2.5))


func _birch(parent: Node3D, pos: Vector3) -> void:
	_cyl(parent, 0.09, 0.13, 3.4, pos + Vector3(0, 1.7, 0), _mat(Color(0.88, 0.88, 0.84)))
	var cm := _mat(Color(0.42, 0.62 + randf() * 0.15, 0.30))
	for k in 2:
		var crown := MeshInstance3D.new()
		var sph := SphereMesh.new()
		sph.radius = 0.95 - k * 0.2
		sph.height = sph.radius * 2.0
		sph.radial_segments = 16
		sph.rings = 8
		crown.mesh = sph
		crown.material_override = cm
		crown.position = pos + Vector3(k * 0.25, 3.7 + k * 0.7, 0)
		parent.add_child(crown)


func _parked_car(parent: Node3D, pos: Vector3) -> void:
	var col: Color = CAR_COLORS.pick_random()
	_box(parent, Vector3(1.8, 0.65, 4.2), pos + Vector3(0, 0.62, 0), _mat(col, 0.0, 0.32, 0.25))
	_box(parent, Vector3(1.6, 0.6, 2.3), pos + Vector3(0, 1.22, -0.1), _mat(Color(0.08, 0.12, 0.20), 0.0, 0.06, 0.6))
	var tyre := _mat(Color(0.05, 0.05, 0.06), 0.0, 0.9)
	for z: float in [-1.4, 1.4]:
		for sx: float in [-0.9, 0.9]:
			var wheel := _cyl(parent, 0.32, 0.32, 0.24, pos + Vector3(sx, 0.32, z), tyre)
			wheel.rotation_degrees.z = 90.0


func _crane(parent: Node3D, pos: Vector3) -> void:
	var yel := _mat(Color(0.95, 0.70, 0.10), 0.0, 0.6, 0.2)
	_box(parent, Vector3(1.4, 48.0, 1.4), pos + Vector3(0, 24.0, 0), yel)
	_box(parent, Vector3(34.0, 1.2, 1.2), pos + Vector3(-4.0, 48.6, 0), yel)
	_box(parent, Vector3(2.4, 2.4, 2.4), pos + Vector3(0, 46.6, 0), _mat(Color(0.25, 0.27, 0.30)))
	_box(parent, Vector3(4.0, 2.0, 2.0), pos + Vector3(11.0, 47.8, 0), _mat(Color(0.35, 0.35, 0.38)))


# препятствия «Мурино»: те же размеры и правила, другой вид
func _wheels(root: Node3D, zs: Array, x: float, r: float) -> void:
	var tyre := _mat(Color(0.05, 0.05, 0.06), 0.0, 0.9)
	for z: float in zs:
		for sx: float in [-1.0, 1.0]:
			var wheel := _cyl(root, r, r, 0.3, Vector3(sx * x, r, z), tyre)
			wheel.rotation_degrees.z = 90.0


func _build_truck(root: Node3D, big: bool) -> Dictionary:
	var vlen := 14.0 if big else 8.0
	var h := 2.9 if big else 2.5
	var base := 0.35 if big else 0.5
	var accent: Color = MURINO_VEH_COLORS.pick_random()
	var glass := _mat(Color(0.08, 0.12, 0.20), 0.0, 0.06, 0.6)
	_box(root, Vector3(2.0, 0.5, vlen - 0.6), Vector3(0, 0.3, 0), _mat(Color(0.10, 0.10, 0.12)))
	var lamp := _mat(Color(1.0, 0.95, 0.6), 2.0)
	if big:
		# фура: кабина спереди, длинный фургон сзади
		_box(root, Vector3(2.1, 2.7, 3.2), Vector3(0, base + 1.35, vlen * 0.5 - 1.6), _mat(accent, 0.0, 0.32, 0.25))
		_box(root, Vector3(1.8, 0.9, 0.06), Vector3(0, base + 1.9, vlen * 0.5 + 0.02), glass)
		_box(root, Vector3(2.2, h, vlen - 3.6), Vector3(0, base + h * 0.5, -1.8), _mat(Color(0.88, 0.89, 0.92), 0.0, 0.55))
		_box(root, Vector3(2.24, 0.3, vlen - 3.6), Vector3(0, base + h * 0.35, -1.8), _mat(accent))
		_wheels(root, [vlen * 0.5 - 1.6, -vlen * 0.5 + 1.6, -vlen * 0.5 + 3.2], 0.98, 0.42)
	else:
		# маршрутка
		_box(root, Vector3(2.1, h, vlen), Vector3(0, base + h * 0.5, 0), _mat(Color(0.92, 0.92, 0.94), 0.0, 0.32, 0.25))
		_box(root, Vector3(2.14, 0.3, vlen - 0.1), Vector3(0, base + h * 0.3, 0), _mat(accent))
		_box(root, Vector3(2.14, 0.7, vlen - 1.8), Vector3(0, base + h * 0.72, -0.2), glass)
		_box(root, Vector3(1.7, 0.9, 0.06), Vector3(0, base + h * 0.70, vlen * 0.5 + 0.02), glass)
		_wheels(root, [vlen * 0.5 - 1.6, -vlen * 0.5 + 1.6], 0.98, 0.42)
	_box(root, Vector3(0.3, 0.2, 0.08), Vector3(-0.7, base + 0.35, vlen * 0.5 + 0.03), lamp)
	_box(root, Vector3(0.3, 0.2, 0.08), Vector3(0.7, base + 0.35, vlen * 0.5 + 0.03), lamp)
	return {"len": vlen, "shape": Vector3(1.9, base + h, vlen), "cy": (base + h) * 0.5}


func _build_jersey(root: Node3D) -> Dictionary:
	var concrete := _mat(Color(0.62, 0.62, 0.60), 0.0, 0.9)
	_box(root, Vector3(2.0, 0.35, 0.7), Vector3(0, 0.175, 0), concrete)
	_box(root, Vector3(1.9, 0.4, 0.45), Vector3(0, 0.55, 0), concrete)
	_box(root, Vector3(1.92, 0.12, 0.47), Vector3(0, 0.80, 0), _mat(Color(0.95, 0.45, 0.10), 0.4))
	return {"len": 1.6, "shape": Vector3(2.0, 0.9, 0.6), "cy": 0.45}


func _build_skip(root: Node3D) -> Dictionary:
	_box(root, Vector3(1.7, 0.9, 1.2), Vector3(0, 0.5, 0), _mat(Color(0.14, 0.38, 0.62), 0.0, 0.5, 0.2))
	_box(root, Vector3(1.78, 0.1, 1.28), Vector3(0, 0.97, 0), _mat(Color(0.10, 0.10, 0.12)))
	_box(root, Vector3(1.72, 0.14, 1.22), Vector3(0, 0.55, 0), _mat(Color(0.95, 0.80, 0.15)))
	return {"len": 1.6, "shape": Vector3(1.7, 1.0, 1.2), "cy": 0.5}


func _build_gantry(root: Node3D) -> Dictionary:
	var metal := _mat(Color(0.25, 0.26, 0.30), 0.0, 0.45, 0.6)
	_box(root, Vector3(0.2, 2.5, 0.2), Vector3(-1.1, 1.25, 0), metal)
	_box(root, Vector3(0.2, 2.5, 0.2), Vector3(1.1, 1.25, 0), metal)
	for k in 6:
		var c := Color(0.95, 0.45, 0.10) if k % 2 == 0 else Color(0.95, 0.95, 0.92)
		_box(root, Vector3(0.4, 0.7, 0.35), Vector3(-1.0 + k * 0.4, 1.85, 0), _mat(c, 0.2))
	return {"len": 1.2, "shape": Vector3(2.0, 0.75, 0.5), "cy": 1.85}
