extends Node3D
## Меллстрой: побег от фога.
## Вся 3D-сцена (трасса, здания, препятствия, свет, камера) собирается кодом.
## Персонажи и костюмы — ваши PNG / покадровые листы с вырезанным зелёным фоном,
## показанные как 2D-спрайты внутри 3D-мира.

# ---------------------------------------------------------------- настройки
const INTRO_ON_RETRY := true      # показывать костюм №1 и после «Играть снова»
const SHADOWS := true             # выключите на очень слабых телефонах

const LANE_W := 2.4
const ROAD_HALF := 3.7
const SEG_LEN := 40.0
const SEG_COUNT := 4
const SPAWN_Z := -130.0

const START_SPEED := 18.0
const MAX_SPEED := 38.0
const ACCEL := 0.30
const INTRO_SPEED := 8.0
const LANE_SPEED := 26.0
const GRAVITY := 46.0
const JUMP_V := 16.0
const SLIDE_TIME := 0.7

const PLAYER_H := 2.1
const FOG_H := 2.2
const FOG_Z := 3.4
const COIN_H := 1.1
const SPRITE_TILT := 15.0

const CAM_POS := Vector3(0.0, 4.6, 6.4)
const CAM_LOOK := Vector3(0.0, 1.0, -5.0)
const CAM_HFOV := 58.0

const SPRITE_FILTER := BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC

const COSTUME_FPS := 12.0
const COSTUME_DEFS := [
	{"sheet": "res://assets/sprites/costume1_sheet.png", "audio": "res://assets/audio/costume1.ogg",
		"cols": 9, "rows": 10, "frames": 84, "width": 3.2},
	{"sheet": "res://assets/sprites/costume2_sheet.png", "audio": "res://assets/audio/costume2.ogg",
		"cols": 9, "rows": 9, "frames": 81, "width": 3.2},
]

const PALETTE := [
	Color(0.80, 0.62, 0.50), Color(0.62, 0.68, 0.78), Color(0.78, 0.74, 0.60),
	Color(0.55, 0.62, 0.55), Color(0.72, 0.55, 0.62), Color(0.60, 0.58, 0.70),
]
const TRAM_COLORS := [Color(0.80, 0.14, 0.12), Color(0.90, 0.60, 0.10), Color(0.15, 0.55, 0.35)]
const BUS_COLORS := [Color(0.12, 0.45, 0.86), Color(0.85, 0.80, 0.15), Color(0.55, 0.20, 0.65)]

static var _is_retry := false

enum State { INTRO, RUN, DYING, OVER }

# ---------------------------------------------------------------- состояние
var _state: State = State.INTRO
var _t := 0.0
var _run_t := 0.0
var _speed := 0.0
var _dist := 0.0
var _coins_got := 0
var _best := 0
var _lane := 1
var _px := 0.0
var _py := 0.0
var _vy := 0.0
var _slide_t := 0.0
var _shake := 0.0
var _since := 0.0
var _gap := 60.0
var _touch_start := Vector2.ZERO
var _touch_active := false

# ---------------------------------------------------------------- ноды
var _cam: Camera3D
var _player: Area3D
var _pivot: Node3D
var _pspr: Sprite3D
var _pcol: CollisionShape3D
var _pshape: BoxShape3D
var _blob: MeshInstance3D
var _fog: Node3D
var _fog_spr: Sprite3D
var _segs: Array[Node3D] = []
var _obstacles: Array[Area3D] = []
var _coin_nodes: Array[Area3D] = []
var _costs: Array = []
var _cur_cost := -1
var _cost_t := 0.0
var _music: AudioStreamPlayer
var _sfx_pick: AudioStreamPlayer

# ресурсы
var _tex_player: Texture2D
var _tex_fog: Texture2D
var _tex_coin: Texture2D
var _tex_win: ImageTexture
var _tex_win_emit: ImageTexture
var _tex_blob: GradientTexture2D
var _tex_road: ImageTexture
var _tex_walk: ImageTexture
var _mats := {}

# UI
var _lbl_score: Label
var _lbl_coins: Label
var _title: Label
var _over: Control
var _lbl_final: Label
var _lbl_best: Label
var _lbl_over_coins: Label
var _btn_box: VBoxContainer
var _btn_again: Button
var _btn_quit: Button


# ================================================================= запуск
func _ready() -> void:
	randomize()
	_load_best()
	_make_shared()
	_build_environment()
	_build_camera()
	for i in SEG_COUNT:
		_add_segment(20.0 - i * SEG_LEN)
	_build_player()
	_build_fog()
	_build_costumes()
	_build_audio()
	_build_ui()
	if _is_retry and not INTRO_ON_RETRY:
		_start_run()
	else:
		_start_intro()
	_is_retry = true


func _start_intro() -> void:
	_state = State.INTRO
	_speed = INTRO_SPEED
	_pivot.visible = false
	_blob.visible = false
	_play_costume(0)


func _start_run() -> void:
	_state = State.RUN
	_run_t = 0.0
	_pivot.visible = true
	_blob.visible = true
	_since = 0.0
	_gap = 70.0
	_music.play()
	if _title != null:
		var tw := create_tween()
		tw.tween_property(_title, "modulate:a", 0.0, 0.6)
	_spawn_row(-75.0)


func _crash() -> void:
	if _state != State.RUN:
		return
	_state = State.DYING
	_music.stop()
	_pivot.visible = false
	_blob.visible = false
	_best = maxi(_best, _score())
	_save_best()
	_shake = 1.0
	_play_costume(1)
	_show_over_title()


# ================================================================= ресурсы
func _load_tex_mips(path: String) -> Texture2D:
	## Картинка с мипмапами и «подчищенными» краями альфы — гладкий силуэт на расстоянии.
	var src: Texture2D = load(path)
	var img: Image = src.get_image()
	if img == null:
		return src
	if img.is_compressed():
		img.decompress()
	img.convert(Image.FORMAT_RGBA8)
	img.fix_alpha_edges()
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func _make_shared() -> void:
	_tex_player = _load_tex_mips("res://assets/sprites/mellstroy.png")
	_tex_fog = _load_tex_mips("res://assets/sprites/fog.png")
	_tex_coin = _load_tex_mips("res://assets/sprites/chekushka.png")
	# фасад с окнами: albedo + emission (горящие окна), рамы, переплёты, подоконники
	var a := Image.create_empty(128, 256, true, Image.FORMAT_RGBA8)
	var e := Image.create_empty(128, 256, true, Image.FORMAT_RGBA8)
	a.fill(Color(1, 1, 1, 1))
	e.fill(Color(0, 0, 0, 1))
	var frame := Color(0.74, 0.74, 0.76)
	var sill := Color(0.62, 0.62, 0.64)
	for row in 8:
		for col in 4:
			var ox := col * 32 + 6
			var oy := row * 32 + 8
			var r := Rect2i(ox, oy, 20, 16)
			a.fill_rect(Rect2i(ox - 2, oy - 2, 24, 20), frame)
			a.fill_rect(Rect2i(ox - 3, oy + 18, 26, 3), sill)
			var lit := randf() < 0.4
			if lit:
				a.fill_rect(Rect2i(r.position.x, r.position.y, r.size.x, 8), Color(0.98, 0.90, 0.62))
				a.fill_rect(Rect2i(r.position.x, r.position.y + 8, r.size.x, 8), Color(0.88, 0.72, 0.44))
				e.fill_rect(Rect2i(r.position.x, r.position.y, r.size.x, 8), Color(1.0, 0.78, 0.38))
				e.fill_rect(Rect2i(r.position.x, r.position.y + 8, r.size.x, 8), Color(0.85, 0.55, 0.24))
			else:
				a.fill_rect(Rect2i(r.position.x, r.position.y, r.size.x, 8), Color(0.20, 0.27, 0.40))
				a.fill_rect(Rect2i(r.position.x, r.position.y + 8, r.size.x, 8), Color(0.10, 0.14, 0.22))
			# переплёт
			a.fill_rect(Rect2i(ox + 9, oy, 2, 16), frame)
			a.fill_rect(Rect2i(ox, oy + 7, 20, 2), frame)
			if lit:
				e.fill_rect(Rect2i(ox + 9, oy, 2, 16), Color(0, 0, 0, 1))
				e.fill_rect(Rect2i(ox, oy + 7, 20, 2), Color(0, 0, 0, 1))
	a.generate_mipmaps()
	e.generate_mipmaps()
	_tex_win = ImageTexture.create_from_image(a)
	_tex_win_emit = ImageTexture.create_from_image(e)
	# асфальт: мелкое зерно
	var ri := Image.create_empty(128, 128, true, Image.FORMAT_RGBA8)
	for y in 128:
		for x in 128:
			var n := randf_range(-0.035, 0.035)
			if randf() < 0.02:
				n += 0.06
			ri.set_pixel(x, y, Color(0.17 + n, 0.17 + n, 0.19 + n, 1.0))
	ri.generate_mipmaps()
	_tex_road = ImageTexture.create_from_image(ri)
	# тротуарная плитка: швы + зерно
	var wi := Image.create_empty(64, 64, true, Image.FORMAT_RGBA8)
	for y in 64:
		for x in 64:
			var n2 := randf_range(-0.02, 0.02)
			var seam := (x % 32 < 2) or (y % 32 < 2)
			var v := (0.46 if seam else 0.58) + n2
			wi.set_pixel(x, y, Color(v, v - 0.01, v - 0.03, 1.0))
	wi.generate_mipmaps()
	_tex_walk = ImageTexture.create_from_image(wi)
	# мягкая тень под игроком
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0, 0, 0, 0.60), Color(0, 0, 0, 0.30), Color(0, 0, 0, 0.0)])
	g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	_tex_blob = GradientTexture2D.new()
	_tex_blob.gradient = g
	_tex_blob.fill = GradientTexture2D.FILL_RADIAL
	_tex_blob.fill_from = Vector2(0.5, 0.5)
	_tex_blob.fill_to = Vector2(1.0, 0.5)
	_tex_blob.width = 128
	_tex_blob.height = 128


func _mat(c: Color, emit: float = 0.0, rough: float = 0.85, metal: float = 0.0) -> StandardMaterial3D:
	var key := "%s|%s|%s|%s" % [c.to_html(), emit, rough, metal]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	m.metallic_specular = 0.5
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emit
	_mats[key] = m
	return m


func _tex_mat(tex: Texture2D, uv_scale: Vector3, rough: float = 0.9) -> StandardMaterial3D:
	var key := "tex|%s|%s" % [tex.get_rid().get_id(), uv_scale]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.uv1_scale = uv_scale
	m.roughness = rough
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	m.texture_repeat = true
	_mats[key] = m
	return m


func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


func _cyl(parent: Node3D, r_top: float, r_bot: float, h: float, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r_top
	cm.bottom_radius = r_bot
	cm.height = h
	cm.radial_segments = 16
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


## 2D-картинка (или покадровый лист) как Sprite3D. Низ спрайта стоит в точке пивота.
func _make_sprite(tex: Texture2D, height: float, hframes: int = 1, vframes: int = 1) -> Node3D:
	var pivot := Node3D.new()
	var s := Sprite3D.new()
	s.texture = tex
	s.hframes = hframes
	s.vframes = vframes
	var fh := float(tex.get_height()) / float(vframes)
	s.pixel_size = height / fh
	s.alpha_cut = SpriteBase3D.ALPHA_CUT_OPAQUE_PREPASS   # сглаженные края силуэта
	s.alpha_scissor_threshold = 0.5
	s.shaded = false
	s.texture_filter = SPRITE_FILTER
	s.position.y = height * 0.5
	pivot.rotation_degrees.x = -SPRITE_TILT
	pivot.add_child(s)
	return pivot


# ================================================================= мир
func _build_environment() -> void:
	var horizon := Color(0.95, 0.74, 0.60)
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.24, 0.40, 0.76)
	sm.sky_horizon_color = horizon
	sm.ground_horizon_color = horizon
	sm.ground_bottom_color = Color(0.45, 0.40, 0.45)
	sm.sky_curve = 0.18
	sm.ground_curve = 0.04
	sm.sun_angle_max = 30.0
	sm.sun_curve = 0.15
	var sky := Sky.new()
	sky.sky_material = sm
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.62, 0.66, 0.82)
	env.ambient_light_energy = 0.85
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.05
	# свечение горящих окон и фонарей
	env.glow_enabled = true
	env.glow_intensity = 0.55
	env.glow_strength = 1.0
	env.glow_bloom = 0.0
	env.glow_hdr_threshold = 0.9
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	# цветокоррекция
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.06
	env.adjustment_saturation = 1.14
	env.fog_enabled = true
	env.fog_light_color = horizon
	env.fog_density = 0.016
	env.fog_sky_affect = 0.0
	env.fog_sun_scatter = 0.15
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
	sun.light_color = Color(1.0, 0.90, 0.78)
	sun.light_energy = 1.15
	sun.shadow_enabled = SHADOWS
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_split_1 = 0.25
	sun.directional_shadow_max_distance = 60.0
	sun.directional_shadow_blend_splits = true
	sun.shadow_blur = 1.4
	sun.shadow_normal_bias = 1.0
	add_child(sun)


func _build_camera() -> void:
	_cam = Camera3D.new()
	_cam.keep_aspect = Camera3D.KEEP_WIDTH   # три полосы влезают на любом портретном экране
	_cam.fov = CAM_HFOV
	_cam.near = 0.1
	_cam.far = 220.0
	add_child(_cam)
	_cam.current = true
	_cam.position = CAM_POS
	_cam.look_at(CAM_LOOK)


func _add_segment(z0: float) -> void:
	var s := Node3D.new()
	s.position.z = z0
	add_child(s)
	_segs.append(s)
	# дорога
	_box(s, Vector3(ROAD_HALF * 2.0, 0.4, SEG_LEN + 0.05), Vector3(0, -0.2, -SEG_LEN * 0.5), _tex_mat(_tex_road, Vector3(ROAD_HALF * 2.0 / 2.0, SEG_LEN / 2.0, 1.0), 0.8))
	# разметка
	var white := _mat(Color(0.85, 0.85, 0.80))
	for sx: float in [-0.5, 0.5]:
		for k in 5:
			_box(s, Vector3(0.14, 0.02, 4.0), Vector3(sx * LANE_W, 0.01, -4.0 - k * 8.0), white)
	for side: int in [-1, 1]:
		# тротуар
		_box(s, Vector3(2.2, 0.3, SEG_LEN + 0.05), Vector3(side * (ROAD_HALF + 1.1), 0.15, -SEG_LEN * 0.5), _tex_mat(_tex_walk, Vector3(1.1, SEG_LEN / 2.0, 1.0), 0.9))
		# здания
		var zc := 0.0
		while zc > -SEG_LEN + 6.0:
			var d := minf(randf_range(10.0, 16.0), SEG_LEN + zc)
			var w := randf_range(7.0, 13.0)
			var h := randf_range(10.0, 34.0)
			_building(s, Vector3(side * (ROAD_HALF + 2.5 + w * 0.5), h * 0.5, zc - d * 0.5), Vector3(w, h, d), side)
			zc -= d + randf_range(0.0, 1.5)
		# фонари
		for zl: float in [-8.0, -28.0]:
			_lamp(s, Vector3(side * (ROAD_HALF + 0.5), 0.0, zl), side)
		# дерево
		var tz := randf_range(-16.0, -4.0)
		var tx := side * (ROAD_HALF + 1.6)
		_cyl(s, 0.12, 0.17, 1.8, Vector3(tx, 0.9, tz), _mat(Color(0.35, 0.24, 0.15)))
		var crown := MeshInstance3D.new()
		var sph := SphereMesh.new()
		sph.radius = 1.1
		sph.height = 2.2
		sph.radial_segments = 20
		sph.rings = 10
		crown.mesh = sph
		crown.material_override = _mat(Color(0.20, 0.45 + randf() * 0.2, 0.22))
		crown.position = Vector3(tx, 2.7, tz)
		s.add_child(crown)
		# мусорный бак
		_box(s, Vector3(1.3, 1.1, 1.9), Vector3(side * (ROAD_HALF + 1.4), 0.85, randf_range(-36.0, -24.0)), _mat(Color(0.18, 0.36, 0.28)))


func _building(parent: Node3D, center: Vector3, size: Vector3, side: int) -> void:
	var col: Color = PALETTE.pick_random()
	_box(parent, size, center, _mat(col))
	var q := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(size.z, size.y)
	q.mesh = qm
	var m := StandardMaterial3D.new()
	m.albedo_texture = _tex_win
	m.albedo_color = col.lightened(0.12)
	m.uv1_scale = Vector3(size.z / 12.0, size.y / 24.0, 1.0)
	m.roughness = 0.9
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	m.emission_enabled = true
	m.emission = Color(1, 1, 1)
	m.emission_texture = _tex_win_emit
	m.emission_energy_multiplier = 1.1
	q.material_override = m
	q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	q.position = Vector3(center.x - side * (size.x * 0.5 + 0.03), center.y, center.z)
	q.rotation_degrees.y = -90.0 * side
	parent.add_child(q)
	if randf() < 0.5:
		_box(parent, Vector3(size.x * 0.4, 1.6, size.z * 0.3), Vector3(center.x, center.y + size.y * 0.5 + 0.8, center.z), _mat(Color(0.30, 0.30, 0.33)))


func _lamp(parent: Node3D, pos: Vector3, side: int) -> void:
	var metal := _mat(Color(0.22, 0.23, 0.27), 0.0, 0.45, 0.6)
	_cyl(parent, 0.07, 0.10, 5.2, pos + Vector3(0, 2.6, 0), metal)
	_box(parent, Vector3(1.1, 0.08, 0.08), pos + Vector3(-side * 0.55, 5.2, 0), metal)
	_box(parent, Vector3(0.5, 0.12, 0.3), pos + Vector3(-side * 1.05, 5.12, 0), _mat(Color(1.0, 0.85, 0.55), 2.5))


# ================================================================= препятствия
func _build_vehicle(root: Node3D, tram: bool) -> Dictionary:
	var vlen := 14.0 if tram else 8.0
	var h := 2.9 if tram else 2.5
	var base := 0.35 if tram else 0.5
	var body: Color = TRAM_COLORS.pick_random() if tram else BUS_COLORS.pick_random()
	var glass := _mat(Color(0.08, 0.12, 0.20), 0.0, 0.06, 0.6)
	_box(root, Vector3(2.0, 0.5, vlen - 1.0), Vector3(0, 0.3, 0), _mat(Color(0.10, 0.10, 0.12)))
	_box(root, Vector3(2.1, h, vlen), Vector3(0, base + h * 0.5, 0), _mat(body, 0.0, 0.32, 0.25))
	_box(root, Vector3(2.14, 0.22, vlen - 0.1), Vector3(0, base + h * 0.36, 0), _mat(Color(0.95, 0.92, 0.85)))
	_box(root, Vector3(2.14, 0.8, vlen - 1.6), Vector3(0, base + h * 0.72, 0), glass)
	_box(root, Vector3(1.7, 1.0, 0.06), Vector3(0, base + h * 0.70, vlen * 0.5 + 0.02), glass)
	var lamp := _mat(Color(1.0, 0.95, 0.6), 2.0)
	_box(root, Vector3(0.3, 0.2, 0.08), Vector3(-0.7, base + 0.35, vlen * 0.5 + 0.03), lamp)
	_box(root, Vector3(0.3, 0.2, 0.08), Vector3(0.7, base + 0.35, vlen * 0.5 + 0.03), lamp)
	_box(root, Vector3(1.4, 0.25, vlen * 0.4), Vector3(0, base + h + 0.12, 0), _mat(Color(0.55, 0.57, 0.60), 0.0, 0.5, 0.5))
	return {"len": vlen, "shape": Vector3(1.9, base + h, vlen), "cy": (base + h) * 0.5}


func _build_barrier(root: Node3D) -> Dictionary:
	var post := _mat(Color(0.85, 0.85, 0.85))
	_box(root, Vector3(0.18, 0.9, 0.18), Vector3(-0.85, 0.45, 0), post)
	_box(root, Vector3(0.18, 0.9, 0.18), Vector3(0.85, 0.45, 0), post)
	_box(root, Vector3(2.0, 0.45, 0.2), Vector3(0, 0.62, 0), _mat(Color(0.85, 0.12, 0.10)))
	for sx: float in [-0.6, 0.0, 0.6]:
		_box(root, Vector3(0.32, 0.46, 0.22), Vector3(sx, 0.62, 0), post)
	return {"len": 1.6, "shape": Vector3(2.0, 0.9, 0.6), "cy": 0.45}


func _build_crate(root: Node3D) -> Dictionary:
	_box(root, Vector3(1.7, 1.0, 1.2), Vector3(0, 0.5, 0), _mat(Color(0.60, 0.42, 0.22)))
	var strap := _mat(Color(0.35, 0.24, 0.12))
	_box(root, Vector3(1.74, 0.12, 1.24), Vector3(0, 0.15, 0), strap)
	_box(root, Vector3(1.74, 0.12, 1.24), Vector3(0, 0.85, 0), strap)
	return {"len": 1.6, "shape": Vector3(1.7, 1.0, 1.2), "cy": 0.5}


func _build_overhead(root: Node3D) -> Dictionary:
	var metal := _mat(Color(0.25, 0.26, 0.30), 0.0, 0.45, 0.6)
	_box(root, Vector3(0.2, 2.5, 0.2), Vector3(-1.05, 1.25, 0), metal)
	_box(root, Vector3(0.2, 2.5, 0.2), Vector3(1.05, 1.25, 0), metal)
	_box(root, Vector3(2.3, 0.7, 0.35), Vector3(0, 1.85, 0), _mat(Color(0.95, 0.78, 0.10)))
	var dark := _mat(Color(0.10, 0.10, 0.10))
	for sx: float in [-0.7, 0.0, 0.7]:
		_box(root, Vector3(0.3, 0.72, 0.37), Vector3(sx, 1.85, 0), dark)
	return {"len": 1.2, "shape": Vector3(2.0, 0.75, 0.5), "cy": 1.85}


func _spawn_obstacle(kind: String, lane: int, z_near: float) -> void:
	var a := Area3D.new()
	a.monitoring = false
	a.set_meta("kind", "hazard")
	var info: Dictionary
	match kind:
		"tram": info = _build_vehicle(a, true)
		"bus": info = _build_vehicle(a, false)
		"barrier": info = _build_barrier(a)
		"crate": info = _build_crate(a)
		_: info = _build_overhead(a)
	var col := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = info["shape"]
	col.shape = bs
	col.position.y = info["cy"]
	a.add_child(col)
	a.position = Vector3((lane - 1) * LANE_W, 0.0, z_near - float(info["len"]) * 0.5)
	add_child(a)
	_obstacles.append(a)


func _spawn_coin(lane: int, z: float, y: float) -> void:
	var a := Area3D.new()
	a.monitoring = false
	a.set_meta("kind", "coin")
	var piv := _make_sprite(_tex_coin, COIN_H)
	a.add_child(piv)
	a.set_meta("spr", piv.get_child(0))
	a.set_meta("ph", randf() * TAU)
	var col := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.0, COIN_H, 0.8)
	col.shape = bs
	col.position.y = COIN_H * 0.5
	a.add_child(col)
	a.position = Vector3((lane - 1) * LANE_W, y - COIN_H * 0.5, z)
	add_child(a)
	_coin_nodes.append(a)


func _spawn_coin_line(lane: int, z_start: float, count: int) -> void:
	for i in maxi(count, 0):
		_spawn_coin(lane, z_start - i * 2.0, 0.95)


## Создаёт ряд препятствий (всегда остаётся свободная полоса). Возвращает дистанцию до следующего ряда.
func _spawn_row(z_near: float) -> float:
	var lanes: Array[int] = [0, 1, 2]
	lanes.shuffle()
	var diff := clampf(_run_t / 90.0, 0.0, 1.0)
	var r := randf()
	var length := 1.6
	if r < 0.30:
		var n := 2 if randf() < 0.25 + 0.35 * diff else 1
		for i in n:
			_spawn_obstacle(["barrier", "crate"].pick_random(), lanes[i], z_near)
		_spawn_coin_line(lanes[n], z_near - 0.5, 5)
	elif r < 0.45:
		length = 1.2
		var n2 := 2 if randf() < 0.2 + 0.3 * diff else 1
		for i in n2:
			_spawn_obstacle("overhead", lanes[i], z_near)
		_spawn_coin_line(lanes[n2], z_near - 0.5, 4)
	elif r < 0.78:
		var tram := randf() < 0.5
		length = 14.0 if tram else 8.0
		_spawn_obstacle("tram" if tram else "bus", lanes[0], z_near)
		_spawn_coin_line(lanes[1], z_near - 1.0, int(length / 2.2))
		if randf() < 0.45:
			_spawn_obstacle("barrier", lanes[2], z_near - 2.0)
	else:
		var tram2 := randf() < 0.5
		length = 14.0 if tram2 else 8.0
		var k2 := "tram" if tram2 else "bus"
		_spawn_obstacle(k2, lanes[0], z_near)
		_spawn_obstacle(k2, lanes[1], z_near)
		_spawn_coin_line(lanes[2], z_near - 1.0, int(length / 2.2))
	return length + 14.0 + _speed * 0.7 + randf() * 10.0


func _spawn_logic(delta: float) -> void:
	_since += _speed * delta
	if _since >= _gap:
		var over := _since - _gap
		_since = over
		_gap = _spawn_row(SPAWN_Z + over)


# ================================================================= игрок
func _build_player() -> void:
	_player = Area3D.new()
	_player.monitorable = false
	_player.area_entered.connect(_on_player_area)
	_pcol = CollisionShape3D.new()
	_pshape = BoxShape3D.new()
	_pcol.shape = _pshape
	_player.add_child(_pcol)
	_set_hitbox(false)
	_pivot = _make_sprite(_tex_player, PLAYER_H)
	_pspr = _pivot.get_child(0) as Sprite3D
	_player.add_child(_pivot)
	add_child(_player)

	_blob = MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(1.5, 1.5)
	_blob.mesh = qm
	var bm := StandardMaterial3D.new()
	bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bm.albedo_texture = _tex_blob
	_blob.material_override = bm
	_blob.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_blob.rotation_degrees.x = -90.0
	_blob.position = Vector3(0, 0.04, 0)
	add_child(_blob)


func _set_hitbox(sliding: bool) -> void:
	if sliding:
		_pshape.size = Vector3(0.8, 0.8, 0.8)
		_pcol.position.y = 0.4
	else:
		_pshape.size = Vector3(0.8, 1.8, 0.8)
		_pcol.position.y = 0.9


func _move_lane(dir: int) -> void:
	if _state != State.RUN:
		return
	_lane = clampi(_lane + dir, 0, 2)


func _jump() -> void:
	if _state != State.RUN:
		return
	if _py <= 0.0 and _vy <= 0.0:
		_vy = JUMP_V
		_py = 0.001
		_slide_t = 0.0
		_set_hitbox(false)


func _slide() -> void:
	if _state != State.RUN:
		return
	if _py <= 0.0:
		_slide_t = SLIDE_TIME
		_set_hitbox(true)
	else:
		_vy = -28.0   # быстро вниз в воздухе


func _update_player(delta: float) -> void:
	var tx := (_lane - 1) * LANE_W
	_px = move_toward(_px, tx, LANE_SPEED * delta)
	if _py > 0.0 or _vy > 0.0:
		_vy -= GRAVITY * delta
		_py += _vy * delta
		if _py <= 0.0:
			_py = 0.0
			_vy = 0.0
	if _slide_t > 0.0:
		_slide_t -= delta
		if _slide_t <= 0.0:
			_set_hitbox(false)
	var on_ground := _py <= 0.0
	var sliding := _slide_t > 0.0
	var bob := 0.0
	var sx := 1.0
	var sy := 1.0
	var swing := 0.0
	if sliding:
		sx = 1.18
		sy = 0.45
	elif on_ground:
		bob = absf(sin(_run_t * 15.0)) * 0.16
		swing = sin(_run_t * 15.0) * 6.0
	var lean := clampf((tx - _px) * 8.0, -14.0, 14.0)
	_player.position = Vector3(_px, _py, 0.0)
	_pivot.position.y = bob
	_pspr.scale = Vector3(sx, sy, 1.0)
	_pspr.position.y = PLAYER_H * 0.5 * sy
	_pspr.rotation_degrees.z = swing + lean
	var bs := 1.0 / (1.0 + _py * 0.3)
	_blob.position.x = _px
	_blob.scale = Vector3(bs, bs, 1.0)


func _on_player_area(area: Area3D) -> void:
	if _state != State.RUN:
		return
	var kind: String = area.get_meta("kind", "")
	if kind == "coin":
		_coin_nodes.erase(area)
		area.queue_free()
		_coins_got += 1
		_sfx_pick.play()
	elif kind == "hazard":
		_crash()


# ================================================================= костюмы
func _build_costumes() -> void:
	for d in COSTUME_DEFS:
		var tex: Texture2D = load(d["sheet"])
		var cols: int = d["cols"]
		var rows: int = d["rows"]
		var fw := float(tex.get_width()) / float(cols)
		var fh := float(tex.get_height()) / float(rows)
		var height: float = float(d["width"]) * fh / fw
		var piv := _make_sprite(tex, height, cols, rows)
		piv.visible = false
		add_child(piv)
		var st: AudioStream = load(d["audio"])
		var ap := AudioStreamPlayer.new()
		ap.stream = st
		add_child(ap)
		var dur := st.get_length()
		if dur < 0.5:
			dur = float(d["frames"]) / COSTUME_FPS
		_costs.append({"pivot": piv, "spr": piv.get_child(0), "audio": ap, "frames": d["frames"], "dur": dur})


func _play_costume(i: int) -> void:
	_cur_cost = i
	_cost_t = 0.0
	var c: Dictionary = _costs[i]
	var piv: Node3D = c["pivot"]
	var x := clampf(_px * 0.6, -1.3, 1.3) if i == 1 else 0.0
	piv.position = Vector3(x, 0.0, 0.6)
	var spr: Sprite3D = c["spr"]
	spr.frame = 0
	piv.visible = true
	var ap: AudioStreamPlayer = c["audio"]
	ap.play()


func _update_costume(delta: float) -> void:
	if _cur_cost < 0:
		return
	_cost_t += delta
	var c: Dictionary = _costs[_cur_cost]
	var spr: Sprite3D = c["spr"]
	spr.frame = mini(int(_cost_t * COSTUME_FPS), int(c["frames"]) - 1)
	if _cost_t >= float(c["dur"]):
		var i := _cur_cost
		_cur_cost = -1
		var piv: Node3D = c["pivot"]
		piv.visible = false
		if i == 0:
			_start_run()      # костюм №1 закончился — снова обычный Меллстрой, играет музыка
		else:
			_state = State.OVER
			_enable_buttons() # костюм №2 закончился — кнопки


# ================================================================= фог
func _build_fog() -> void:
	_fog = _make_sprite(_tex_fog, FOG_H)
	_fog_spr = _fog.get_child(0) as Sprite3D
	_fog.position = Vector3(0, 0, FOG_Z)
	add_child(_fog)


func _animate_fog(delta: float) -> void:
	var tx := _px
	var tz := FOG_Z
	if _state == State.INTRO:
		tx = 0.0
	elif _state == State.DYING:
		tz = 3.0
	elif _state == State.OVER:
		tx = _px * 0.6
		tz = 1.2
	_fog.position.x = lerpf(_fog.position.x, tx, 1.0 - exp(-5.0 * delta))
	_fog.position.z = lerpf(_fog.position.z, tz, 1.0 - exp(-3.0 * delta))
	var ph := _t * 11.0
	_fog.position.y = absf(sin(ph)) * 0.25
	_fog_spr.rotation_degrees.z = sin(ph) * 5.0


# ================================================================= процесс
func _physics_process(delta: float) -> void:
	_t += delta
	match _state:
		State.INTRO:
			_speed = INTRO_SPEED
			_scroll_world(delta)
			_update_costume(delta)
		State.RUN:
			_run_t += delta
			_speed = minf(START_SPEED + ACCEL * _run_t, MAX_SPEED)
			_dist += _speed * delta
			_update_player(delta)
			_scroll_world(delta)
			_spawn_logic(delta)
			_animate_coins()
			_update_hud()
		State.DYING:
			_update_costume(delta)
	_animate_fog(delta)
	_update_camera(delta)


func _scroll_world(delta: float) -> void:
	var dz := _speed * delta
	for s in _segs:
		s.position.z += dz
	var i := _obstacles.size() - 1
	while i >= 0:
		var o := _obstacles[i]
		o.position.z += dz
		if o.position.z > 24.0:
			o.queue_free()
			_obstacles.remove_at(i)
		i -= 1
	i = _coin_nodes.size() - 1
	while i >= 0:
		var c := _coin_nodes[i]
		c.position.z += dz
		if c.position.z > 14.0:
			c.queue_free()
			_coin_nodes.remove_at(i)
		i -= 1
	if _segs[0].position.z - SEG_LEN > 10.0:
		var old: Node3D = _segs.pop_front()
		old.queue_free()
		_add_segment(_segs.back().position.z - SEG_LEN)


func _animate_coins() -> void:
	for c in _coin_nodes:
		var spr: Sprite3D = c.get_meta("spr")
		var ph: float = c.get_meta("ph")
		var w := _t * 6.0 + ph
		spr.position.y = COIN_H * 0.5 + sin(w) * 0.08
		spr.rotation_degrees.z = sin(w * 0.8) * 12.0


func _update_camera(delta: float) -> void:
	var cx := _px * 0.5
	var sh := Vector3.ZERO
	if _shake > 0.0:
		sh = Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), 0.0) * _shake * 0.25
		_shake = maxf(0.0, _shake - delta * 1.2)
	_cam.position = CAM_POS + Vector3(cx, 0.0, 0.0) + sh
	_cam.look_at(CAM_LOOK + Vector3(cx * 0.9, 0.0, 0.0))


# ================================================================= ввод
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var te := event as InputEventScreenTouch
		_touch_active = te.pressed
		if te.pressed:
			_touch_start = te.position
	elif event is InputEventScreenDrag and _touch_active:
		var de := event as InputEventScreenDrag
		var d := de.position - _touch_start
		if d.length() >= 50.0:
			_touch_active = false
			if absf(d.x) > absf(d.y):
				_move_lane(1 if d.x > 0.0 else -1)
			elif d.y < 0.0:
				_jump()
			else:
				_slide()
	elif event is InputEventKey:
		var ke := event as InputEventKey
		if ke.pressed and not ke.echo:
			match ke.keycode:
				KEY_LEFT, KEY_A: _move_lane(-1)
				KEY_RIGHT, KEY_D: _move_lane(1)
				KEY_UP, KEY_W, KEY_SPACE: _jump()
				KEY_DOWN, KEY_S: _slide()


# ================================================================= звук
func _build_audio() -> void:
	_music = AudioStreamPlayer.new()
	var ms = load("res://assets/audio/submelltheme.mp3")
	if ms is AudioStreamMP3:
		ms.loop = true
	_music.stream = ms
	_music.volume_db = -3.0
	add_child(_music)
	_sfx_pick = AudioStreamPlayer.new()
	_sfx_pick.stream = load("res://assets/audio/pickup.wav")
	_sfx_pick.volume_db = -4.0
	add_child(_sfx_pick)


# ================================================================= рекорд
func _score() -> int:
	return int(_dist) + _coins_got * 10


func _load_best() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://mellstroy.cfg") == OK:
		_best = int(cf.get_value("game", "best", 0))


func _save_best() -> void:
	var cf := ConfigFile.new()
	cf.set_value("game", "best", _best)
	cf.save("user://mellstroy.cfg")


# ================================================================= интерфейс
func _label(text: String, size: int, col: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", int(size * 0.12))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _style_btn(b: Button, col: Color) -> void:
	for st in ["normal", "hover", "pressed", "focus", "disabled"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = col.lightened(0.18) if st == "pressed" else col
		sb.set_corner_radius_all(32)
		sb.set_border_width_all(6)
		sb.border_color = Color.WHITE
		sb.shadow_color = Color(0, 0, 0, 0.45)
		sb.shadow_size = 14
		sb.shadow_offset = Vector2(0, 6)
		b.add_theme_stylebox_override(st, sb)
	b.add_theme_font_size_override("font_size", 60)
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_disabled_color", Color.WHITE)
	b.custom_minimum_size = Vector2(780, 150)


## Отступ сверху под вырез/чёлку экрана (в единицах viewport).
func _safe_top() -> float:
	var win := DisplayServer.window_get_size()
	if win.x <= 0:
		return 24.0
	var safe := DisplayServer.get_display_safe_area()
	var k := get_viewport().get_visible_rect().size.x / float(win.x)
	return maxf(24.0, float(safe.position.y) * k)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var top := _safe_top()

	# HUD: счёт слева, чекушки справа
	var hud := HBoxContainer.new()
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	hud.offset_left = 40.0
	hud.offset_right = -40.0
	hud.offset_top = top + 24.0
	hud.offset_bottom = top + 124.0
	_lbl_score = _label("0", 68)
	_lbl_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	_lbl_score.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hud.add_child(_lbl_score)
	var icon := TextureRect.new()
	icon.texture = _tex_coin
	icon.custom_minimum_size = Vector2(60, 100)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(icon)
	_lbl_coins = _label("0", 68)
	hud.add_child(_lbl_coins)

	# заголовок в начале
	_title = _label("МЕЛЛСТРОЙ\nПОБЕГ ОТ ФОГА", 100, Color(1.0, 0.85, 0.2))
	root.add_child(_title)
	_title.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_title.offset_top = top + 220.0
	_title.offset_bottom = top + 520.0

	# Game Over
	_over = Control.new()
	_over.visible = false
	root.add_child(_over)
	_over.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	_over.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_over.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 26)
	center.add_child(vb)
	vb.add_child(_label("GAME OVER", 130, Color(1.0, 0.25, 0.2)))
	_lbl_final = _label("", 70)
	vb.add_child(_lbl_final)
	_lbl_over_coins = _label("", 56)
	vb.add_child(_lbl_over_coins)
	_lbl_best = _label("", 56, Color(1.0, 0.85, 0.2))
	vb.add_child(_lbl_best)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 30)
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(gap)
	_btn_box = VBoxContainer.new()
	_btn_box.add_theme_constant_override("separation", 28)
	_btn_box.modulate.a = 0.0
	vb.add_child(_btn_box)
	_btn_again = Button.new()
	_btn_again.text = "ИГРАТЬ СНОВА"
	_style_btn(_btn_again, Color(0.15, 0.62, 0.25))
	_btn_again.disabled = true
	_btn_again.pressed.connect(_on_again)
	_btn_box.add_child(_btn_again)
	_btn_quit = Button.new()
	_btn_quit.text = "ВЫЙТИ"
	_style_btn(_btn_quit, Color(0.70, 0.18, 0.18))
	_btn_quit.disabled = true
	_btn_quit.pressed.connect(_on_quit)
	_btn_box.add_child(_btn_quit)


func _update_hud() -> void:
	_lbl_score.text = "%d м" % _score()
	_lbl_coins.text = " %d" % _coins_got


func _show_over_title() -> void:
	_update_hud()
	_lbl_final.text = "Счёт: %d" % _score()
	_lbl_over_coins.text = "Чекушек: %d" % _coins_got
	_lbl_best.text = "Рекорд: %d" % _best
	_over.modulate.a = 0.0
	_over.visible = true
	create_tween().tween_property(_over, "modulate:a", 1.0, 0.35)


func _enable_buttons() -> void:
	_btn_again.disabled = false
	_btn_quit.disabled = false
	create_tween().tween_property(_btn_box, "modulate:a", 1.0, 0.3)


func _on_again() -> void:
	get_tree().reload_current_scene()


func _on_quit() -> void:
	get_tree().quit()
