# Меллстрой побег от фога (Godot 4.7, Android)

Package name: `com.Damir4ik.mellstroyrun` · портрет 9:16 · рендерер GL Compatibility.

## Запуск
1. Откройте папку проекта в Godot 4.7 (первый запуск импортирует ассеты).
2. F5 — играть. На ПК: ← → смена полосы, ↑/Space прыжок, ↓ подкат. На телефоне: свайпы.

## Сборка APK
1. Установите JDK 17 и Android SDK (platform-tools, build-tools 35.0.1, platform android-35, cmdline-tools), укажите пути: Editor → Editor Settings → Export → Android.
2. Editor → Manage Export Templates → установите шаблоны своей версии Godot.
3. Project → Export → Android (пресет уже настроен: пакет, имя, иконки, arm64-v8a) → Export Project.
   Командой: `godot --headless --import` и затем
   `godot --headless --export-debug "Android" build/mellstroy_run.apk`
4. Для релиза: в пресете включите Gradle Build (для AAB) и укажите release keystore.

Ориентация: Project Settings → Display → Window → Handheld → Orientation = Portrait
(Android-экспорт берёт значение отсюда — горизонтальный режим запрещён).

## Что где
- `scripts/main.gd` — вся игра (мир, препятствия, игрок, костюмы, UI). Настройки сверху файла.
- `assets/sprites` — персонажи без фона (`mellstroy`, `artur`, `kotost`, `zaych`); `costume*_sheet.png` — кадры костюмов (12 к/с).
- `assets/audio` — музыка, звуки костюмов (из ваших mp4), звук подбора.

Лобби: после запуска открывается лобби — по центру выбранный персонаж, нажатие на него открывает
выбор и магазин персонажей, кнопка «ИГРАТЬ» запускает забег. Персонажи: Меллстрой (основной),
Артур — 60 чекушек, Заяц бурмалдаец — 80, Котость — 100. Чекушки, собранные в забегах, копятся
и сохраняются вместе с покупками и выбранным персонажем (`user://mellstroy.cfg`).
Список персонажей и цены — `CHAR_DEFS` в начале `scripts/main.gd`.

Поток игры: лобби → костюм №1 (со своим звуком) → выбранный персонаж + музыка → столкновение →
музыка стоп, костюм №2 (со своим звуком) → GAME OVER, «Играть снова» (возврат в лобби) / «Выйти».
